"""
candidates.py

Goal: get pairs of words that are worth comparing, without having to
compare every word with every other word (that would be V^2 comparisons).

Two ways to do it:
  1. cdist_pairs()    - compares everything using rapidfuzz in chunks. Exact,
                        but only practical for smaller vocabularies (~50k words).
  2. blocking_pairs() - puts words into "buckets" using cheap keys and only
                        compares words that share a bucket. Works for big vocab.

candidate_pairs() chooses one of them depending on the config.
Use this right after the vocabulary is built.
"""

from collections import defaultdict
from itertools import combinations

import numpy as np
from rapidfuzz import process
from rapidfuzz.distance import Levenshtein

from config import CFG

# the vowels that skeleton() removes
VOWELS = set("aeiou")


# bucket key #1 (blocking): the word without its vowels
def skeleton(word):
    # removes the vowels, so politiko and pulitiko both become pltk
    result = ""
    for ch in word:
        if ch not in VOWELS:
            result += ch
    return result


# bucket key #2 (blocking): the word with one letter removed, at every position
def deletion_keys(word):
    # delete one letter at every position. Two words that are 1 edit apart
    # will share at least one of these (idea taken from SymSpell)
    keys = set()                                    # set, so repeated results (e.g. from double letters) are stored once
    for i in range(len(word)):
        keys.add(word[:i] + word[i + 1:])           # everything before position i + everything after it
    return keys


# method 1: exact. compares every word against every other word, but in chunks so memory stays small
def cdist_pairs(words, max_edit=2, chunk=1000, n_jobs=-1):
    """Yields every pair (a, b) with a < b whose Levenshtein distance is <= max_edit."""
    words = sorted(words)                           # sorted so each pair comes out in alphabetical order

    # go through the words in chunks so the distance matrix doesn't get too big
    for start in range(0, len(words), chunk):
        part = words[start:start + chunk]           # the next 1000 words
        # matrix[r][c] = edit distance between part[r] and words[c]. workers = number of CPU cores,
        # score_cutoff skips calculations that go above max_edit, dtype uint8 keeps the matrix small
        matrix = process.cdist(part, words, scorer=Levenshtein.distance,
                               score_cutoff=max_edit, dtype=np.uint8, workers=n_jobs)

        # positions (row, column) of all the cells where the distance is small enough
        rows, cols = np.nonzero(matrix <= max_edit)
        for r, c in zip(rows, cols):
            i = start + r                           # row position -> position in the full sorted list
            # only keep the pair when c > i, otherwise we get duplicates
            # (this also skips a word paired with itself, since its distance is 0 at c == i)
            if c > i:
                yield words[i], words[c]


# method 2: fast. only compares words that share a bucket. can miss some pairs
def blocking_pairs(words, key_funcs=(skeleton, deletion_keys), max_block=300):
    # step 1: put every word into buckets
    # blocks[(key function name, key)] = set of words with that key
    blocks = defaultdict(set)
    for word in words:
        for key_func in key_funcs:
            if key_func is deletion_keys:
                keys = key_func(word)       # this one gives many keys
            else:
                keys = [key_func(word)]     # this one gives just one key
            for key in keys:
                # the function name is part of the bucket name so a skeleton key and a deletion key can't be mixed up
                blocks[(key_func.__name__, key)].add(word)

    # step 2: compare the words inside each bucket
    seen = set()                                    # pairs already yielded (two words can share several buckets)
    for block in blocks.values():
        # skip buckets that are too small or too big (huge ones are mostly noise)
        if len(block) < 2 or len(block) > max_block:
            continue
        # every possible pair of words inside the bucket, once each
        for a, b in combinations(sorted(block), 2):
            if (a, b) not in seen:
                seen.add((a, b))
                yield a, b


# picks the method. this is the function pipeline.py calls
def candidate_pairs(words, cfg=CFG):
    words = list(words)

    # "auto": exact method for up to 50,000 words, blocking for bigger vocabularies
    if cfg.method == "auto":
        if len(words) <= 50_000:
            method = "cdist"
        else:
            method = "blocking"
    else:
        method = cfg.method                         # "cdist" or "blocking" chosen by hand in config.py

    if method == "cdist":
        return cdist_pairs(words, cfg.max_edit, n_jobs=cfg.n_jobs)
    return blocking_pairs(words, max_block=cfg.block_max_size)


# quick demo: python candidates.py
if __name__ == "__main__":
    test_words = ["politiko", "pulitiko", "opo", "upo", "bahay", "polittico"]
    print("cdist   :", sorted(cdist_pairs(test_words)))
    print("blocking:", sorted(blocking_pairs(test_words)))
