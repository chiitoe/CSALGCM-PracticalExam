"""
grouping.py  --  turn pairs into variant FAMILIES and clean them (Greedy choices).
  group_variants()  : Union-Find (own) -- merges transitive variants  a~b, b~c  =>  {a,b,c}
  group_variants_nx : same with networkx
  canonical()       : greedy pick of the most frequent spelling
  drop_hubs()       : remove words linked to too many partners (usually false positives)
WHEN TO USE : after scoring, before writing Variants.csv.
"""
from collections import Counter
import networkx as nx
from config import CFG

# Union-Find (disjoint set): keeps track of which words belong to the same group.
# find(x) = "which group is x in?", union(a, b) = "put a and b in the same group"
# NOT used in run() - only drop_hubs() is. this is extra material for the report
class UnionFind:
    # self.p maps each word to its "parent". a word that is its own parent is the group's leader
    def __init__(self): self.p = {}
    def find(self, x):
        self.p.setdefault(x, x)                              # a new word starts in its own group
        while self.p[x] != x:                                # follow the parents up to the leader
            self.p[x] = self.p[self.p[x]]; x = self.p[x]     # path compression (shortcut so next time is faster)
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)                  # find the leader of each word
        if ra != rb: self.p[rb] = ra                         # different groups -> attach one leader to the other

# merges pairs into families: (a,b) and (b,c) -> {a,b,c}, even though a and c were never paired
def group_variants(pairs):
    uf = UnionFind()
    for a, b in pairs: uf.union(a, b)                        # link every pair
    groups = {}
    # collect the words by their leader, so each leader maps to the list of words in its group
    for w in list(uf.p): groups.setdefault(uf.find(w), []).append(w)
    return [sorted(g) for g in groups.values()]

# same result as group_variants, but using networkx: pairs become edges in a graph,
# and each connected component (a set of linked words) is one family
def group_variants_nx(pairs):
    G = nx.Graph(); G.add_edges_from(pairs)
    return [sorted(c) for c in nx.connected_components(G)]

# greedy choice: the "main" spelling of a family is the one that appears most often in the data
def canonical(group, counts):
    return max(group, key=lambda w: counts.get(w, 0))

# step 4 of run(): removes pairs that contain a "hub" word (a word with too many partners)
def drop_hubs(pairs, cfg=CFG):
    """Keep only pairs whose both words have <= max_partners partners."""
    pairs = list(pairs)
    # deg[w] = in how many pairs the word w appears
    deg = Counter(w for p in pairs for w in p)
    # keep a pair only if BOTH of its words have at most max_partners partners (default 6)
    return [p for p in pairs if deg[p[0]] <= cfg.max_partners and deg[p[1]] <= cfg.max_partners]

# quick demo: python grouping.py
if __name__ == "__main__":
    ps = [("politiko", "pulitiko"), ("pulitiko", "pulitikoh")]
    print(group_variants(ps), group_variants_nx(ps), drop_hubs(ps))
