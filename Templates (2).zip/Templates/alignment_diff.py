"""
alignment_diff.py  --  WHICH characters differ?  Builds the `character_difference` column.
  align()                : own DP + traceback (report material)
  diff_chunks(a, b)      : [(x, y), ...] merged contiguous edits, e.g. [('o','u')] or [('ts','ch')]
  character_difference() : "o vs. u"  (several chunks joined by "; ")
WHEN TO USE : output column + rule mining. A deletion/insertion is shown with '-' (change SYMBOL if your spec differs).
"""
from rapidfuzz.distance import Levenshtein as RF

# what to print when a letter was deleted/inserted (the "empty side" of the difference), e.g. "h vs. -"
SYMBOL = "-"

# own version of the alignment (for the report). it finds the distance AND which edits were made.
# NOT used in the main pipeline - diff_chunks() below does this job with rapidfuzz
def align(a, b):
    """Own DP + traceback. Returns (distance, [(op, char_a, char_b, pos_in_a)])."""
    n, m = len(a), len(b)

    # D[i][j] = edit distance between the first i letters of a and the first j letters of b
    D = [[0] * (m + 1) for _ in range(n + 1)]
    # first column / row: turning a word into an empty word (or the reverse) costs one edit per letter
    for i in range(n + 1): D[i][0] = i
    for j in range(m + 1): D[0][j] = j

    # fill the table: each cell is the cheapest of delete / insert / substitute (0 if the letters match)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            D[i][j] = min(D[i-1][j] + 1, D[i][j-1] + 1, D[i-1][j-1] + (a[i-1] != b[j-1]))

    # traceback: walk from the bottom-right corner back to the top-left,
    # at each cell checking which move produced its value, and record the edit
    ops, i, j = [], n, m
    while i > 0 or j > 0:
        if i and j and D[i][j] == D[i-1][j-1] + (a[i-1] != b[j-1]):
            # diagonal move: letters match (no edit) or were substituted
            if a[i-1] != b[j-1]: ops.append(("sub", a[i-1], b[j-1], i - 1))
            i, j = i - 1, j - 1
        elif i and D[i][j] == D[i-1][j] + 1:
            # moved up: a letter of a was deleted
            ops.append(("del", a[i-1], "", i - 1)); i -= 1
        else:
            # moved left: a letter of b was inserted
            ops.append(("ins", "", b[j-1], i)); j -= 1
    # the traceback goes backwards, so reverse the list to get the edits in word order
    return D[n][m], ops[::-1]

# finds the parts that differ, with neighbouring edits merged into one block
# e.g. ("tsaa", "chaa") -> [("ts", "ch")], not two separate single-letter edits
def diff_chunks(a, b):
    """Merged edit blocks via rapidfuzz opcodes: [(text_in_a, text_in_b), ...]."""
    # opcodes = list of (tag, start_a, end_a, start_b, end_b). skip the "equal" parts,
    # and slice out the differing text from each word
    return [(a[i1:i2], b[j1:j2]) for tag, i1, i2, j1, j2 in RF.opcodes(a, b) if tag != "equal"]

# makes the text for the character_difference column in Variants.csv, e.g. "o vs. u"
# an empty side (insertion/deletion) is shown as SYMBOL, several blocks are joined with "; "
def character_difference(a, b):
    return "; ".join(f"{x or SYMBOL} vs. {y or SYMBOL}" for x, y in diff_chunks(a, b))

# quick demo: python alignment_diff.py
if __name__ == "__main__":
    print(align("politiko", "pulitiko"))
    for a, b in [("politiko", "pulitiko"), ("tsaa", "chaa"), ("bahay", "bay")]:
        print(a, b, "->", character_difference(a, b))
