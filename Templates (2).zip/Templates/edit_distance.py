"""
edit_distance.py

Different versions of the Levenshtein edit distance (dynamic programming).

  levenshtein()          - normal DP version written by hand
  bounded_levenshtein()  - DP that only looks at a band around the diagonal and
                           stops early if the distance is already above k
  weighted_levenshtein() - DP with custom costs, e.g. o <-> u costs 0.3 instead of 1
  fast_distance()        - rapidfuzz version (C++), used for the full run
  damerau()              - like Levenshtein but swapping 2 neighbours is 1 edit

The hand-written ones are for explaining the method in the report, and
rapidfuzz is used when speed matters.
"""

from rapidfuzz.distance import Levenshtein as RF
from rapidfuzz.distance import DamerauLevenshtein as RFD

from config import CFG, INDEL_OK, is_alternation


# the basic edit distance: the minimum number of insertions, deletions and substitutions
# needed to turn word a into word b. "politiko" -> "pulitiko" = 1 (o -> u)
def levenshtein(a, b):
    """Standard DP. Time O(n*m), but only two rows are kept so memory is O(min(n,m))."""
    # make a the longer word so the rows are as short as possible
    if len(a) < len(b):
        a, b = b, a

    # row 0 of the table: turning an empty word into b[:j] costs j insertions
    previous_row = list(range(len(b) + 1))

    for i in range(1, len(a) + 1):
        # first cell of the row: turning a[:i] into an empty word costs i deletions
        current_row = [i]
        for j in range(1, len(b) + 1):
            # substitution costs 0 if the letters already match, otherwise 1
            if a[i - 1] == b[j - 1]:
                sub_cost = 0
            else:
                sub_cost = 1

            delete = previous_row[j] + 1                    # from the cell above
            insert = current_row[j - 1] + 1                 # from the cell to the left
            substitute = previous_row[j - 1] + sub_cost     # from the diagonal cell
            current_row.append(min(delete, insert, substitute))   # take the cheapest option
        previous_row = current_row                          # the finished row becomes the "previous" row

    # the last cell of the last row = distance between the full words
    return previous_row[-1]


# faster version when you only care whether the distance is small (<= k).
# not used in the main run (rapidfuzz does this in C++), it is for the report
def bounded_levenshtein(a, b, k):
    """
    Returns the distance if it is <= k, otherwise returns k + 1.
    Only cells within k of the diagonal are filled in, so it is O(k * min(n,m)).
    """
    # if the lengths differ by more than k there is no way to be within k
    if abs(len(a) - len(b)) > k:
        return k + 1

    if len(a) < len(b):
        a, b = b, a

    n = len(a)
    m = len(b)
    INF = k + 1  # anything bigger than k is treated as "too far"

    # first row, but cells further than k from the start are already "too far"
    previous_row = []
    for j in range(m + 1):
        if j <= k:
            previous_row.append(j)
        else:
            previous_row.append(INF)

    for i in range(1, n + 1):
        current_row = [INF] * (m + 1)                       # start with every cell "too far"
        if i <= k:
            current_row[0] = i
        row_min = current_row[0]                            # smallest value in this row (for the early stop)

        # only the band around the diagonal
        # (cells further than k from the diagonal can never lead to a distance <= k)
        start = max(1, i - k)
        end = min(m, i + k)
        for j in range(start, end + 1):
            if a[i - 1] == b[j - 1]:
                sub_cost = 0
            else:
                sub_cost = 1

            # same three options as the normal version, capped at INF
            value = min(previous_row[j] + 1,
                        current_row[j - 1] + 1,
                        previous_row[j - 1] + sub_cost,
                        INF)
            current_row[j] = value
            row_min = min(row_min, value)

        # the whole row is already above k -> can stop early
        if row_min > k:
            return INF
        previous_row = current_row

    return min(previous_row[m], INF)


# cost of replacing letter x with letter y (used by weighted_levenshtein)
def _sub_cost(x, y, cfg):
    # cost of replacing letter x with letter y
    if x == y:
        return 0
    if is_alternation(x, y):
        return cfg.alt_sub_cost         # known alternation like o/u -> cheap (0.3)
    return 1.0                          # any other substitution -> full cost


# cost of inserting / deleting letter x (used by weighted_levenshtein)
def _indel_cost(x, cfg):
    # cost of inserting / deleting letter x
    if x in INDEL_OK:
        return cfg.indel_ok_cost        # allowed letter like h -> cheaper (0.5)
    return 1.0                          # any other letter -> full cost


# same DP as levenshtein(), but different edits have different costs, so "politiko"/"pulitiko"
# counts as 0.3 instead of 1. this feeds the `lexical` signal in scoring.py.
# rapidfuzz can't do custom costs, so this one is always used for real (not just the report)
def weighted_levenshtein(a, b, cfg=CFG):
    """
    Same DP but with different costs:
      allowed alternation (like o/u) -> cfg.alt_sub_cost
      allowed insert/delete          -> cfg.indel_ok_cost
      everything else                -> 1
    """
    n = len(a)
    m = len(b)

    # first row: turning an empty string into b[:j]
    previous_row = [0.0] * (m + 1)
    for j in range(1, m + 1):
        previous_row[j] = previous_row[j - 1] + _indel_cost(b[j - 1], cfg)

    for i in range(1, n + 1):
        # first cell of the row: deleting the first i letters of a
        current_row = [previous_row[0] + _indel_cost(a[i - 1], cfg)]
        for j in range(1, m + 1):
            delete = previous_row[j] + _indel_cost(a[i - 1], cfg)
            insert = current_row[j - 1] + _indel_cost(b[j - 1], cfg)
            substitute = previous_row[j - 1] + _sub_cost(a[i - 1], b[j - 1], cfg)
            current_row.append(min(delete, insert, substitute))
        previous_row = current_row

    return previous_row[-1]


# the fast distance used in score_pair(). if k is given and the real distance is bigger,
# rapidfuzz stops early and returns k + 1
def fast_distance(a, b, k=None):
    """rapidfuzz version. If k is given and the distance is bigger than k, returns k + 1."""
    return RF.distance(a, b, score_cutoff=k)


# like levenshtein, but swapping two neighbouring letters ("ie" -> "ei") is 1 edit instead of 2
# not used in the pipeline, just an extra option
def damerau(a, b):
    """Swapping two neighbouring letters (like 'ie' vs 'ei') counts as only one edit."""
    return RFD.distance(a, b)


# quick demo: python edit_distance.py
if __name__ == "__main__":
    tests = [("politiko", "pulitiko"), ("politiko", "polittico"), ("opo", "upo")]
    for a, b in tests:
        # my own DP should give the same answer as rapidfuzz
        assert levenshtein(a, b) == fast_distance(a, b)
        print(a, b,
              "lev =", levenshtein(a, b),
              "bounded2 =", bounded_levenshtein(a, b, 2),
              "weighted = %.2f" % weighted_levenshtein(a, b),
              "damerau =", damerau(a, b))
