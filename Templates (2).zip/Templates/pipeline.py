"""
pipeline.py - main file. Runs all the stages and writes Variants.csv
(and Evaluation.xlsx for the evaluation step).

How to run:
  pip install -r requirements.txt
  python pipeline.py eda   dataset.txt     # 1. look at the data (vocab size, hapax, top words)
  python pipeline.py mine  dataset.txt     # 2. find the real alternations (o/u, e/i...) -> edit config.py
  python pipeline.py run   dataset.txt     # 3. full pipeline -> Variants.csv (+ debug_scored.csv)
  python pipeline.py eval  Variants.csv    # 4. random 100 pairs -> Evaluation.xlsx with precision formula

Stages:
  load -> vocab filter -> candidate pairs (edit distance) -> rule filter
       -> context evidence -> score each pair -> drop hubs -> sort -> CSV

Other files:
  config.py, data_loading.py, edit_distance.py, alignment_diff.py,
  candidates.py, rule_mining.py, scoring.py, grouping.py, parallel_dc.py
"""

import argparse
import random

import pandas as pd
from tqdm import tqdm

from config import CFG
from data_loading import build_vocab, collect_evidence, eda
from candidates import candidate_pairs
from rule_mining import mine_rules, suggest_classes, rule_explains
from scoring import score_pair
from grouping import drop_hubs
from alignment_diff import character_difference

# columns for the output file - Variants.csv
COLUMNS = ["word1", "word2", "word1_count", "word2_count", "character_difference"]

def vocab_for_pairing(cfg=CFG):
    # count all the words, then keep only the ones frequent / long enough
        # infrequent words are dropped since they're more likely to be spelling errs
        # shorter words are dropped since they're more likely to be completely different words. eg. opo and upo
    
    counts = build_vocab(cfg)       # counts how many times a word appears in the dataset

    words = []
    for word, count in counts.items():                                  # for every entry in the dataset
        if count >= cfg.min_count and len(word) >= cfg.min_len:         # condition check
            words.append(word)                                          # if passed conditions, add to the filtered list

    print(f"vocab {len(counts):,} -> {len(words):,} after min_count/min_len filters")
    return counts, words


def run(cfg=CFG):
    counts, words = vocab_for_pairing(cfg)

    # step 1: creates list of candidate pairs; keeps only pairs that can be "explained" by our specified rules
    pairs = []
    for pair in tqdm(candidate_pairs(words, cfg), desc="candidates"):
        if rule_explains(pair[0], pair[1], cfg.max_edit):
            pairs.append(pair)
    print(f"{len(pairs):,} candidate pairs survive the rule filter")

    # step 2:  given the filtered candidate pairs, read through the dataset again but also save "evidence" of their neighboring words & which sentences the paired words are in.
    # these will be LATER compared: if the neighboring words are the same/similar, the pair is more likely to be a spelling variant
    targets = set()
    for a, b in pairs:
        targets.add(a)
        targets.add(b)
    contexts, sent_ids = collect_evidence(cfg, targets)

    # step 3: score/compare evidence from step 2 on every pair
    scored = []
    for a, b in tqdm(pairs, desc="scoring"):
        scored.append(score_pair(a, b, counts, contexts, sent_ids, cfg))

    # for debugging - saves everything so far so we can tune the thresholds in debug
    debug_df = pd.DataFrame(scored)
    debug_df.to_csv("debug_scored.csv", index=False)

    # step 4: passes through the pairs and filters out the ones that score_pair rejected
    # also filters out pairs containing a word that's part of MANY pairs since these are more likely to be false positives.
    accepted_pairs = []
    for row in scored:
        if row["accept"]:
            accepted_pairs.append((row["word1"], row["word2"]))
    kept = drop_hubs(accepted_pairs, cfg)

    
    # step 5: builds the output rows by total count from kept pairs: sorts words & formats into Variants.csv
    rows = []
    for a, b in kept:
        w1, w2 = sorted((a, b))
        rows.append((w1, w2, counts[w1], counts[w2], character_difference(w1, w2)))
    df = pd.DataFrame(rows, columns=COLUMNS)

    # sort rows by the total count of both words, biggest first
    df["_total"] = df["word1_count"] + df["word2_count"]
    df = df.sort_values("_total", ascending=False)
    df = df.drop(columns="_total")

    # formatting 
    if cfg.commas_in_counts:
        df["word1_count"] = df["word1_count"].map("{:,}".format)
        df["word2_count"] = df["word2_count"].map("{:,}".format)

    # saves and reports the output
    df.to_csv(cfg.out_csv, index=False, encoding="utf-8")
    print(f"{len(df):,} variant pairs -> {cfg.out_csv}   (rejected pairs + reasons in debug_scored.csv)")
    return df


def mine(cfg=CFG):
    # checks all pairs and "mines out" which alterations occur. these make up the rules used in run()
    counts, words = vocab_for_pairing(cfg)
    df = mine_rules(candidate_pairs(words, cfg), counts)
    print(df.head(30).to_string(index=False))
    print("\nSuggested EQUIV_CLASSES additions:", suggest_classes(df))
    df.to_csv("mined_rules.csv", index=False)


def make_eval_sample(csv_path=None, cfg=CFG):
    # for evaluation - takes a random sample of pairs and creates Evaluation.xlsx
    from openpyxl import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation

    if csv_path is None:
        csv_path = cfg.out_csv
    df = pd.read_csv(csv_path)

    n = min(cfg.eval_sample_size, len(df))
    sample = df.sample(n=n, random_state=cfg.seed).reset_index(drop=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "Evaluation"

    # header row, then one row per sampled pair
    ws.append(["#"] + list(df.columns) + ["is_variant (Yes/No)", "notes"])
    for i, row in sample.iterrows():
        ws.append([i + 1] + list(row.values))

    last_row = n + 1
    answer_col = len(df.columns) + 2
    letter = ws.cell(row=1, column=answer_col).column_letter

    # dropdown with Yes / No
    dropdown = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True)
    ws.add_data_validation(dropdown)
    dropdown.add(f"{letter}2:{letter}{last_row}")

    # small table with the precision calculation
    ws["K1"] = "Yes"
    ws["K2"] = "No"
    ws["K3"] = "Judged"
    ws["K4"] = "Precision"
    ws["L1"] = f'=COUNTIF({letter}2:{letter}{last_row},"Yes")'
    ws["L2"] = f'=COUNTIF({letter}2:{letter}{last_row},"No")'
    ws["L3"] = "=L1+L2"
    ws["L4"] = '=IF(L3=0,"",L1/L3)'
    ws["L4"].number_format = "0.0%"

    # column widths
    widths = (5, 14, 14, 12, 12, 20, 18, 30)
    for column, width in zip("ABCDEFGH", widths):
        ws.column_dimensions[column].width = width

    wb.save(cfg.eval_xlsx)
    print(f"{n} random pairs -> {cfg.eval_xlsx} (fill column {letter}; precision in L4)")


if __name__ == "__main__":
    # command line entry point - runs the functions depending on what command is ran in cmd
    # also updates the output file depending on which func is called

    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("command", choices=["eda", "mine", "run", "eval"])
    parser.add_argument("path", help="dataset path (eda/mine/run) or Variants.csv (eval)")
    parser.add_argument("--out", help="output CSV for `run`")
    args = parser.parse_args()

    if args.command == "eval":
        make_eval_sample(args.path)
    else:
        CFG.dataset_path = args.path
        if args.out:
            CFG.out_csv = args.out

        if args.command == "eda":
            eda(build_vocab(CFG))
        elif args.command == "mine":
            mine()
        else:
            run()
