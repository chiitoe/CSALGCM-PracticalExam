"""
data_loading.py  --  read ANY dataset, normalize, tokenize, count, and gather context evidence.
WHEN TO USE : first step of the pipeline. Also run `python data_loading.py <file>` for a quick EDA.
KEY FUNCTIONS: build_vocab(cfg) -> Counter | collect_evidence(cfg, targets) -> (contexts, sent_ids) | eda(counts)
"""
import json, os, unicodedata
from collections import Counter, defaultdict
import regex
from config import CFG
 
# uses python's regex lib - regular expressions
TOKEN_RE = regex.compile(r"\p{L}+(?:'\p{L}+)?")          # letters of any script (+ inner apostrophe), ignores outer apostrophes, numbers and symbols
SENT_SPLIT = regex.compile(r"(?<=[.!?])\s+|\n+")         # splits paragraphs into sentences
 
# normalizes the dataset so that all characters read the same.
def normalize(text, cfg=CFG):
    # NFKC merges look-alike unicode characters into one standard form,
    # then curly apostrophes and backticks are turned into a straight apostrophe
    text = unicodedata.normalize("NFKC", text).replace("’", "'").replace("`", "'")
    # lowercase so "Politiko" and "politiko" count as the same word (if cfg.lowercase is True)
    return text.lower() if cfg.lowercase else text
 
 
# turns a piece of text into a list of words: normalize first, then pull out only the words using TOKEN_RE
def tokenize(text, cfg=CFG):
    return TOKEN_RE.findall(normalize(text, cfg))
 
# reads the raw text from the dataset. it is a generator (yield), so it hands over one chunk at a time
# instead of loading the whole file into memory
def iter_texts(path=None, cfg=CFG):
    """Yield raw text chunks from a .txt/.csv/.json/.jsonl file or a folder of them."""
    # if no path is given, use the dataset path from config.py
    path = path or cfg.dataset_path
 
    # if the path is a folder, go through the files inside (sorted, so the order is always the same)
    # and read each one by calling this same function again (recursion)
    if os.path.isdir(path):
        for name in sorted(os.listdir(path)):
            yield from iter_texts(os.path.join(path, name), cfg)
        return
 
    # otherwise it is a single file, so check its extension to know how to read it
    ext = os.path.splitext(path)[1].lower()
 
    if ext == ".csv":
        # csv: read only the text column, 50,000 rows at a time so big files don't fill memory
        # bad rows are skipped, empty cells are dropped, and everything is converted to a string
        import pandas as pd
        for chunk in pd.read_csv(path, usecols=[cfg.text_column], chunksize=50_000,
                                 encoding=cfg.encoding, on_bad_lines="skip"):
            yield from chunk[cfg.text_column].dropna().astype(str)
 
    elif ext in (".json", ".jsonl"):
        # errors="ignore" skips characters that can't be decoded instead of crashing
        with open(path, encoding=cfg.encoding, errors="ignore") as f:
            if ext == ".jsonl":
                # jsonl: one json object per line, so read line by line and take the text column.
                # a broken line is just skipped
                for line in f:
                    try: yield str(json.loads(line).get(cfg.text_column, ""))
                    except Exception: continue
            else:
                # json: the whole file is loaded at once. it can be a list of rows or a single row.
                # dict rows -> take the text column, anything else -> use it as the text itself
                data = json.load(f)
                for row in (data if isinstance(data, list) else [data]):
                    yield str(row.get(cfg.text_column, "")) if isinstance(row, dict) else str(row)
 
    else:                                                     # plain text: stream line by line
        with open(path, encoding=cfg.encoding, errors="ignore") as f:
            yield from f
 
# turns the raw text chunks into sentences, and each sentence into a list of words
# e.g. "Ang politiko. Ang pulitiko!" -> ["ang", "politiko"], ["ang", "pulitiko"]
def iter_sentences(path=None, cfg=CFG):
    """Yield token lists, one per sentence."""
    for chunk in iter_texts(path, cfg):
        for sent in SENT_SPLIT.split(chunk):        # split the chunk into sentences
            toks = tokenize(sent, cfg)              # sentence -> list of words
            if toks: yield toks                     # skip sentences with no words (empty lines, numbers only)
 
# first pass over the data: counts how many times each word appears
def build_vocab(cfg=CFG, path=None):
    """Counter of word frequencies (all words; min_count is applied later so EDA stays honest)."""
    counts = Counter()                              # word -> count
    for toks in iter_sentences(path, cfg): counts.update(toks)   # add each sentence's words to the tally
    return counts
 
# second pass over the data: saves the "evidence" (neighbouring words + sentence numbers)
# only for the words inside the candidate pairs, so memory stays small
def collect_evidence(cfg, targets, path=None):
    """
    One extra pass that gathers, ONLY for `targets` (memory-friendly):
      contexts[w] = Counter of neighbouring words within +/- context_window
      sent_ids[w] = set of sentence ids where w occurs (to test co-occurrence)
    """
    targets = set(targets)                          # set makes the "is this a target?" check fast
    # defaultdict creates an empty Counter / set automatically the first time a word is seen
    contexts, sent_ids = defaultdict(Counter), defaultdict(set)
    w = cfg.context_window                          # how many words to look at on each side (default 3)
 
    # sid = sentence number (0, 1, 2, ...). enumerate gives each sentence its number
    for sid, toks in enumerate(iter_sentences(path, cfg)):
        # i = position of the word inside the sentence
        for i, tok in enumerate(toks):
            if tok in targets:
                # neighbours = up to w words before + up to w words after (the word itself is not included).
                # max(0, i - w) stops the "before" slice from going below the start of the sentence
                contexts[tok].update(toks[max(0, i - w):i] + toks[i + 1:i + 1 + w])
                # remember which sentence this word was in (used for the cooc penalty in scoring.py)
                sent_ids[tok].add(sid)
    return contexts, sent_ids
 
# exploratory data analysis: prints quick statistics so you know what the dataset looks like
def eda(counts, cfg=CFG):
    import pandas as pd
    s = pd.Series(counts)                           # word -> count as a pandas table
    # tokens = total words | vocab = different words | hapax = words that appear only once
    # last number = how many words survive the min_count filter
    print(f"tokens: {s.sum():,} | vocab: {len(s):,} | hapax: {(s == 1).sum():,} "
          f"| vocab with count >= {cfg.min_count}: {(s >= cfg.min_count).sum():,}")
    # summary stats (mean, min, max, ...) of the word lengths, useful for choosing min_len
    print("word-length distribution:\n", pd.Series([len(w) for w in s.index]).describe().round(2).to_string())
    # the 15 most frequent words
    print("top 15:", s.sort_values(ascending=False).head(15).to_dict())
 
# runs only when you execute this file directly: python data_loading.py dataset.txt
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1: CFG.dataset_path = sys.argv[1]     # optional: use the file given in the terminal
    eda(build_vocab(CFG))                                    # count the words, then print the stats
 