"""
scoring.py

Decides if two words are the same lexical item using evidence, not only how
similar they look. Signals (all between 0 and 1 unless noted):

  lexical : 1 - weighted_edit_distance / max_edit   (o <-> u is cheap)
  jaro    : Jaro-Winkler similarity
  context : cosine similarity of the neighbour-word counts. This is the main
            signal: real variants show up in the same contexts, while
            different words (opo / upo) do not.
  freq    : min_count / max_count  (a form that is 1 in 1000 is probably a typo)
  cooc    : fraction of sentences where both words appear together
            (variants rarely appear together, so this is a penalty)

First some hard filters (length, edit distance, rule, relative frequency),
then a weighted score is compared to score_threshold.
score_pair() returns a dict so a list of results can go straight into a DataFrame.
"""

import math

from rapidfuzz.distance import JaroWinkler

from config import CFG
from edit_distance import fast_distance, weighted_levenshtein
from rule_mining import rule_explains


# cosine similarity: treats each word's neighbours as a list of counts and measures how
# much they point in the same direction. 1 = same neighbours, 0 = no neighbours in common
def cosine(c1, c2):
    # c1 and c2 are dicts / Counters of context word -> count
    # if either word has no neighbour info, we can't compare -> None (not 0, so it isn't treated as "different")
    if not c1 or not c2:
        return None

    # dot product: for every neighbour of word 1, multiply its count by the count of
    # the same neighbour for word 2 (0 if word 2 never had it) and add them all up
    dot = 0
    for word, value in c1.items():
        dot += value * c2.get(word, 0)

    # length of each vector: square root of the sum of the squared counts
    length1 = math.sqrt(sum(v * v for v in c1.values()))
    length2 = math.sqrt(sum(v * v for v in c2.values()))

    if length1 == 0 or length2 == 0:
        return None
    # cosine = dot product divided by both lengths (so a word that is just more common doesn't score higher)
    return dot / (length1 * length2)


# the main decision: gives one pair a score and an accept/reject flag
# the returned dict becomes one row of debug_scored.csv
def score_pair(a, b, counts, contexts=None, sent_ids=None, cfg=CFG):
    weights = cfg.weights
    # edit distance, stopping early if it is already above max_edit (then it returns max_edit + 1)
    dist = fast_distance(a, b, cfg.max_edit)
    out = dict(word1=a, word2=b, edit=dist, reason="")

    # ---- hard filters: reject right away ----
    # (rejected pairs get score 0 and only a few columns, since the signals are never computed)
    # word too short: short words are different lexical items (opo / upo)
    if min(len(a), len(b)) < cfg.min_len:
        out.update(score=0, accept=False, reason="too short")
        return out

    # words too far apart in spelling
    if dist > cfg.max_edit:
        out.update(score=0, accept=False, reason="edit too large")
        return out

    # the difference isn't an allowed alternation (not in EQUIV_CLASSES / INDEL_OK)
    if not rule_explains(a, b, cfg.max_edit):
        out.update(score=0, accept=False, reason="no rule")
        return out

    # relative frequency: rarer count / commoner count. a very rare form next to a common one is probably a typo
    count_a = counts[a]
    count_b = counts[b]
    freq = min(count_a, count_b) / max(count_a, count_b)
    if freq < cfg.min_rel_freq:
        out.update(score=0, accept=False, reason="rare form (typo?)")
        return out

    # ---- the signals ----
    # lexical: weighted edit distance turned into a 0..1 score (0 edits = 1.0, max_edit or more = 0)
    # max(0.0, ...) stops it from going negative
    lex = max(0.0, 1 - weighted_levenshtein(a, b, cfg) / cfg.max_edit)
    # jaro-winkler: how alike the spellings look (extra credit when the starts match)
    jw = JaroWinkler.similarity(a, b)

    # context: how similar the neighbouring words of a and b are (None if there is no data)
    ctx = None
    if contexts:
        ctx = cosine(contexts.get(a), contexts.get(b))

    # cooc: share of sentences where both words appear together, measured against the word that
    # appears in fewer sentences. high overlap = probably two different words, so it lowers the score
    cooc = 0.0
    if sent_ids and sent_ids.get(a) and sent_ids.get(b):
        both = len(sent_ids[a] & sent_ids[b])               # & = sentences that are in both sets
        cooc = both / min(len(sent_ids[a]), len(sent_ids[b]))

    # if the contexts are clearly different they are probably different words
    if ctx is not None and ctx < cfg.min_context_sim:
        out.update(score=0, accept=False, reason=f"contexts differ ({ctx:.2f})")
        return out

    # when there is no context info, use 0.5 so it doesn't help or hurt
    if ctx is None:
        ctx_used = 0.5
    else:
        ctx_used = ctx

    # ---- final weighted score ----
    # weights from config.py: context 0.40, lexical 0.30, jaro 0.15, freq 0.15
    # freq * 2 (capped at 1): a form that is at least half as common as the other already counts as fully balanced
    score = (weights["context"] * ctx_used
             + weights["lexical"] * lex
             + weights["jaro"] * jw
             + weights["freq"] * min(1, freq * 2))
    # penalty: up to -0.2 when the two words always appear in the same sentences
    score = score - 0.2 * cooc

    # accept if the score reaches the threshold (0.55 by default)
    accepted = score >= cfg.score_threshold
    if accepted:
        reason = "ok"
    else:
        reason = "score below threshold"

    # round the context for the output (it can be None, which can't be rounded)
    if ctx is None:
        ctx_rounded = None
    else:
        ctx_rounded = round(ctx, 3)

    # add everything to the result dict, rounded to 3 decimals so debug_scored.csv stays readable
    out.update(word1_count=count_a, word2_count=count_b,
               lexical=round(lex, 3), jaro=round(jw, 3),
               context=ctx_rounded, freq=round(freq, 3), cooc=round(cooc, 3),
               score=round(score, 3), accept=accepted, reason=reason)
    return out


# quick demo: python scoring.py
# politiko/pulitiko share neighbours -> should be accepted. politiko/polittico is rare and has different contexts -> rejected
if __name__ == "__main__":
    from collections import Counter

    # fake word counts and fake neighbour counts, just for the test
    cnt = Counter({"politiko": 435, "pulitiko": 1093, "polittico": 3})
    ctx = {"politiko": Counter(mga=5, ang=4, bayan=3),
           "pulitiko": Counter(mga=6, ang=5, bayan=2),
           "polittico": Counter(xx=3)}

    for pair in [("politiko", "pulitiko"), ("politiko", "polittico")]:
        print(score_pair(*pair, cnt, ctx))
