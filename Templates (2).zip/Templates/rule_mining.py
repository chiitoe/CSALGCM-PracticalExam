"""
rule_mining.py  --  LEARN which character alternations occur in YOUR dataset (data-driven rules).
WORKFLOW (very useful, do this first!):
  1. python pipeline.py mine <dataset>      -> prints a ranked table of edits (o->u, e->i, ...)
  2. Look at the top rows; the genuine alternations are frequent and shared by many word pairs.
  3. Copy them into EQUIV_CLASSES in config.py.
Also provides rule_explains(a, b): do ALL differences between a and b fall in allowed alternations?
"""
import pandas as pd
from config import CFG, INDEL_OK, is_alternation
from alignment_diff import diff_chunks

# used by the `mine` command: counts which letter swaps happen across all the close pairs
def mine_rules(pairs, counts):
    """pairs: iterable of (a, b) near-neighbours. Returns a DataFrame ranked by #distinct pairs."""
    # rows[(x, y)] = [number of pairs with this swap, total support, example pairs]
    rows = {}
    for a, b in pairs:
        chunks = diff_chunks(a, b)
        if len(chunks) != 1: continue                       # only single-site edits: clean evidence
        x, y = sorted(chunks[0])                            # sorted so o->u and u->o count as the same swap
        r = rows.setdefault((x, y), [0, 0, []])
        # n_pairs +1, support += the smaller of the two word counts, and remember the pair as an example
        r[0] += 1; r[1] += min(counts[a], counts[b]); r[2].append(f"{a}/{b}")
    # turn the dictionary into a table (an empty side is shown as "-"), keeping only 3 examples per swap
    df = pd.DataFrame([(x or "-", y or "-", n, tot, ", ".join(ex[:3]))
                       for (x, y), (n, tot, ex) in rows.items()],
                      columns=["char_1", "char_2", "n_pairs", "support_count", "examples"])
    # most common swaps first (ties broken by support_count)
    return df.sort_values(["n_pairs", "support_count"], ascending=False, ignore_index=True)

# turns the mined table into suggested EQUIV_CLASSES entries for config.py
def suggest_classes(df, min_pairs=5):
    """Quick suggestion of EQUIV_CLASSES lines (single-char pairs only)."""
    # keep swaps seen in at least min_pairs pairs, with a single letter on both sides (no "-" insertions/deletions)
    top = df[(df.n_pairs >= min_pairs) & (df.char_1.str.len() == 1) & (df.char_2.str.len() == 1)
             & (df.char_1 != "-") & (df.char_2 != "-")]
    return [{r.char_1, r.char_2} for r in top.itertuples()]

# the rule filter used in run() and score_pair(): can the rules explain EVERY difference between the two words?
def rule_explains(a, b, max_ops=2):
    """True if every differing block is an allowed substitution (or allowed indel)."""
    chunks = diff_chunks(a, b)
    # identical words (no chunks) or too many separate differences -> not explained
    if not chunks or len(chunks) > max_ops: return False
    for x, y in chunks:
        if x and y:                                         # substitution block
            # both sides must be the same length and every letter pair must be an allowed alternation (o/u, e/i, ...)
            if len(x) != len(y) or not all(is_alternation(p, q) for p, q in zip(x, y)): return False
        elif not set(x + y) <= INDEL_OK:                    # pure insertion/deletion
            # only the letters in INDEL_OK (h, ', -) may be freely inserted or deleted
            return False
    return True

# quick demo: python rule_mining.py  (True for o/u, False for the extra t + k/c)
if __name__ == "__main__":
    print(rule_explains("politiko", "pulitiko"), rule_explains("polittico", "pulitiko"))
