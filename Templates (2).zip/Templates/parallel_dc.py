"""
parallel_dc.py

Divide and conquer helpers, plus running things on multiple cores.

  merge_sort()      - normal divide and conquer sort
  dc_pairs()        - splits a sorted word list in half, solves each half, then
                      compares words near the split (sorted neighbourhood idea)
  divide_by_key()   - DIVIDE the words into independent buckets (by length, first letter...)
  chunked()         - cut a list into pieces of a given size
  parallel_map()    - CONQUER the pieces on all cores using joblib
"""

from collections import defaultdict

from joblib import Parallel, delayed


# classic divide and conquer sort: split the list, sort each half, merge the sorted halves
# NOT imported by pipeline.py - this file is report / explanation material
def merge_sort(items, key=lambda x: x):
    # base case: 0 or 1 items is already sorted
    if len(items) <= 1:
        return list(items)

    # divide
    middle = len(items) // 2
    left = merge_sort(items[:middle], key)          # conquer: sort the left half (recursion)
    right = merge_sort(items[middle:], key)         # conquer: sort the right half

    # merge the two sorted halves
    # i and j point at the next unused item of left and right. take the smaller one each time
    merged = []
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        if key(left[i]) <= key(right[j]):
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1

    # one of the halves still has items left
    # (they are already sorted and bigger than everything merged so far, so just add them to the end)
    merged = merged + left[i:] + right[j:]
    return merged


# finds matching pairs with divide and conquer, instead of comparing every word with every other word
# compare = a function you give it that returns True if two words are a match
def dc_pairs(words, compare, leaf=64, window=20):
    """
    words must be sorted. compare(a, b) returns True if the pair is a match.
      Divide : split the list in two halves
      Conquer: recurse on each half
      Combine: compare the words close to the split line, since pairs
               across the boundary would be missed otherwise
    """
    # base case: small list, just compare everything
    if len(words) <= leaf:
        found = []
        for i in range(len(words)):
            for j in range(i + 1, len(words)):      # j starts after i so each pair is checked once
                if compare(words[i], words[j]):
                    found.append((words[i], words[j]))
        return found

    # divide + conquer: solve each half separately
    middle = len(words) // 2
    left_result = dc_pairs(words[:middle], compare, leaf, window)
    right_result = dc_pairs(words[middle:], compare, leaf, window)
    result = left_result + right_result

    # combine: pairs with one word in each half were never compared, so check the words
    # near the split line (similar words sit close together in a sorted list)
    # words just left of the split vs words just right of the split
    left_edge = words[max(0, middle - window):middle]
    right_edge = words[middle:middle + window]
    for a in left_edge:
        for b in right_edge:
            if compare(a, b):
                result.append((a, b))

    # note: this is a shortcut. a matching pair far apart in the sorted list can still be missed
    return result


# "divide" step for parallel work: groups the items into independent buckets
# e.g. divide_by_key(words, len) -> {5: [...5-letter words], 6: [...], ...}
def divide_by_key(items, keyfunc):
    # groups the items into a dict: key -> list of items
    buckets = defaultdict(list)                     # a new empty list is created the first time a key is seen
    for item in items:
        buckets[keyfunc(item)].append(item)
    return buckets


# cuts a list into pieces of `size` items, e.g. chunked(range(10), 3) -> [[0,1,2], [3,4,5], [6,7,8], [9]]
def chunked(seq, size):
    seq = list(seq)                                 # so generators and ranges also work
    chunks = []
    for i in range(0, len(seq), size):              # jump forward `size` items each time
        chunks.append(seq[i:i + size])
    return chunks


# "conquer" step: runs the function on every chunk at the same time on different CPU cores (joblib)
def parallel_map(fn, chunks, n_jobs=-1):
    """
    fn takes one chunk and returns a list. All the lists are joined together.
    Example: parallel_map(fn, chunked(pairs, 5000))
    """
    # one task per chunk. n_jobs=-1 means use all cores. the result is a list of lists (one per chunk)
    results_per_chunk = Parallel(n_jobs=n_jobs)(delayed(fn)(chunk) for chunk in chunks)

    # combine: join the lists of all the chunks into one flat list
    all_results = []
    for part in results_per_chunk:
        for item in part:
            all_results.append(item)
    return all_results


# quick demo: python parallel_dc.py
if __name__ == "__main__":
    sorted_words = merge_sort(["pulitiko", "politiko", "bahay", "baay"])
    # compare here just checks if the first letters match (a toy rule for the test)
    print(sorted_words, dc_pairs(sorted_words, lambda a, b: a[0] == b[0]))
    # doubles every number, 3 numbers per chunk, on 2 cores
    print(parallel_map(lambda c: [x * 2 for x in c], chunked(range(10), 3), n_jobs=2))
