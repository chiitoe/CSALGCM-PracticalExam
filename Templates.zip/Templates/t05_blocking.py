"""T05 - Candidate generation (blocking) so we avoid O(V^2) comparisons.
Keys: consonant skeleton (vowel alternations), delete-one-char neighborhood (SymSpell idea).
Optional: rapidfuzz.process.extract / cdist for brute-force on small buckets."""
from collections import defaultdict
from itertools import combinations
from rapidfuzz import process
from rapidfuzz.distance import Levenshtein

VOWELS = set("aeiou")

def skeleton(w):
    return "".join(ch for ch in w if ch not in VOWELS)

def deletion_keys(w):
    return {w[:i] + w[i+1:] for i in range(len(w))}

def build_blocks(words, key_funcs):
    blocks = defaultdict(set)
    for w in words:
        for kf in key_funcs:
            keys = kf(w) if kf is deletion_keys else [kf(w)]
            for key in keys:
                blocks[(kf.__name__, key)].add(w)
    return blocks

def candidate_pairs(words, key_funcs=(skeleton,), max_block=500):
    seen = set()
    for block in build_blocks(words, key_funcs).values():
        if len(block) < 2 or len(block) > max_block: continue
        for a, b in combinations(sorted(block), 2):
            if (a, b) not in seen:
                seen.add((a, b)); yield a, b

def neighbors_bruteforce(word, vocab, k=2):
    """rapidfuzz: all vocab words within edit distance k of `word` (fast C++ scan)."""
    return [w for w, d, _ in process.extract(word, vocab, scorer=Levenshtein.distance,
                                             score_cutoff=k, limit=None) if w != word]

if __name__ == "__main__":
    ws = ["politiko", "pulitiko", "opo", "upo", "bahay"]
    print(list(candidate_pairs(ws))); print(neighbors_bruteforce("politiko", ws))
