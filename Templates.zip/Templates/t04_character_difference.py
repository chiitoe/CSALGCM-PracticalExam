"""T04 - Build the `character_difference` column (format: 'o vs. u')."""
from t03_alignment_backtrace import align, fast_align

def character_difference(w1, w2):
    _, ops = fast_align(w1, w2)
    parts = []
    for op, x, y, _pos in ops:
        parts.append(f"{x or '-'} vs. {y or '-'}")   # '-' marks an insertion/deletion
    return "; ".join(parts)

if __name__ == "__main__":
    print(character_difference("politiko", "pulitiko"))  # o vs. u
