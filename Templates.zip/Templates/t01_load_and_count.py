"""T01 - Load a text dataset, tokenize, count word frequencies.
Libs: regex (Unicode-aware tokenizing), collections.Counter, pandas (optional frequency table)."""
import regex
from collections import Counter

TOKEN_RE = regex.compile(r"\p{L}+(?:['’]\p{L}+)?")   # letters (any script), optional inner apostrophe

def tokenize(text, lowercase=True):
    return TOKEN_RE.findall(text.lower() if lowercase else text)

def load_counts(path, encoding="utf-8", min_count=1):
    counts = Counter()
    with open(path, "r", encoding=encoding, errors="ignore") as f:
        for line in f:                        # stream: safe for large files
            counts.update(tokenize(line))
    if min_count > 1:
        counts = Counter({w: c for w, c in counts.items() if c >= min_count})
    return counts

def counts_to_df(counts):
    import pandas as pd
    return (pd.DataFrame(counts.items(), columns=["word", "count"])
              .sort_values("count", ascending=False, ignore_index=True))

if __name__ == "__main__":
    import sys
    c = load_counts(sys.argv[1])
    print(len(c), "unique words"); print(counts_to_df(c).head(10))
