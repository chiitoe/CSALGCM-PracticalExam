"""T03 - Which characters differ? (a) own DP table + traceback, (b) rapidfuzz editops."""
from rapidfuzz.distance import Levenshtein as RFLev

def align(a, b):
    n, m = len(a), len(b)
    D = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1): D[i][0] = i
    for j in range(m + 1): D[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            D[i][j] = min(D[i-1][j] + 1, D[i][j-1] + 1, D[i-1][j-1] + (a[i-1] != b[j-1]))
    ops, i, j = [], n, m
    while i > 0 or j > 0:
        if i > 0 and j > 0 and D[i][j] == D[i-1][j-1] + (a[i-1] != b[j-1]):
            if a[i-1] != b[j-1]: ops.append(("sub", a[i-1], b[j-1], i - 1))
            i, j = i - 1, j - 1
        elif i > 0 and D[i][j] == D[i-1][j] + 1:
            ops.append(("del", a[i-1], "", i - 1)); i -= 1
        else:
            ops.append(("ins", "", b[j-1], i)); j -= 1
    ops.reverse()
    return D[n][m], ops

def fast_align(a, b):
    """Same output format via rapidfuzz.editops (replace->sub, insert->ins, delete->del)."""
    name = {"replace": "sub", "insert": "ins", "delete": "del"}
    ops = []
    for op in RFLev.editops(a, b):
        x = a[op.src_pos] if op.tag in ("replace", "delete") else ""
        y = b[op.dest_pos] if op.tag in ("replace", "insert") else ""
        ops.append((name[op.tag], x, y, op.src_pos))
    return RFLev.distance(a, b), ops

if __name__ == "__main__":
    print(align("politiko", "pulitiko")); print(fast_align("politiko", "pulitiko"))
