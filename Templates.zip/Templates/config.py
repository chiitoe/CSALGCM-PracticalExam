"""
config.py  --  ONE place for every setting and linguistic rule.
WHEN TO USE : edit this first; every other module reads CFG from here.
TUNE THESE  : min_count, min_len, max_edit, score_threshold, EQUIV_CLASSES.
"""
from dataclasses import dataclass, field

@dataclass
class Config:
    # ---- input / output ----
    dataset_path: str = "dataset.txt"      # file OR folder of .txt/.csv/.json/.jsonl
    text_column: str = "text"              # used for csv / json inputs
    out_csv: str = "Variants.csv"          # output file
    encoding: str = "utf-8"
    commas_in_counts: bool = False         # True -> "1,093"; False -> "1093"

    # ---- vocabulary filters ----
    lowercase: bool = True
    min_count: int = 2                     # drop hapax / typos
    min_len: int = 7                       # short words (opo/upo) are different lexical items

    # ---- candidate generation ----
    max_edit: int = 2                      # max Levenshtein distance for a candidate
    method: str = "auto"                   # how candidate pairs are generated:
                                           # "cdist" - compares every word against every other word using the rapidfuzz library (fast string comparison), in blocks.
                                                # very accurate, though scales with large datasets. too slow when dataset >= 50,000 words (estimate)
                                           # "blocking" - groups words into "buckets" via cheap keys (word without its vowels or with one letter deleted). compares words with shared buckets.
                                                # a shortcut that can miss pairs cdist can find. though much faster on bigger datasets
                                           # "auto"  - measures the size of the dataset and decides which between cdist and blocking is applicable
    block_max_size: int = 300              # skip giant, uninformative blocks. these are likely just noise and not actual variants.

    # ---- scoring ----
    context_window: int = 3                # the # of words on either side of a word ("neighbors"). used in collect_evidence
    min_rel_freq: float = 0.01             # hard filter on frequency. rarer form must be >= 1% of the commoner form. these are likely spelling errs and not variants
    min_context_sim: float = 0.15          # hard filter on context. rejects words that look similar but is used in different contexts
    score_threshold: float = 0.55          # final accept threshold (0..1) the higher the %, the stricter the scoring
    weights: dict = field(default_factory=lambda: dict(
        context=0.40,
        lexical=0.30,
        jaro=0.15,
        freq=0.15))

    # the costs are for the levenshtein and edit distance algos
    alt_sub_cost: float = 0.3              # cost of a "known alternation" substitution (o<->u)
    indel_ok_cost: float = 0.5             # cost of inserting/deleting an allowed char (h, ')

    # ---- grouping ----
    max_partners: int = 6                  # a word with more partners than this is suspicious - words typically only have a small number of spelling variants.
    
    # ---- evaluation ----
    eval_sample_size: int = 100
    eval_xlsx: str = "Evaluation.xlsx"
    seed: int = 6                          # starting value of the random sampler. different seed = different set of 100 samples
    n_jobs: int = -1                       # -1 = all CPU cores

CFG = Config()

# ---------- linguistic rules (EDIT AFTER running `python pipeline.py mine ...`) ----------
# Characters in the same set are allowed to alternate: politiko/pulitiko (o<->u), etc.
EQUIV_CLASSES = [
    {"o", "u"}, {"e", "i"}, {"k", "c"}, {"f", "p"},
    {"s", "z"}, {"w", "u"}, {"y", "i"}, {"j", "h"}, {"b", "v"},

    # dropped classes:  {"d", "r"}
]
INDEL_OK = {"h", "'", "-"}                 # may be inserted/deleted freely

ALLOWED_SUBS = {frozenset((x, y)) for cls in EQUIV_CLASSES for x in cls for y in cls if x != y}

def is_alternation(x: str, y: str) -> bool:
    # True if substituting x<->y is an allowed alternation.
    return frozenset((x, y)) in ALLOWED_SUBS