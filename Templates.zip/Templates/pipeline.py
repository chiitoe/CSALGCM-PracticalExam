"""
pipeline.py  --  THE ENTRY POINT. Runs every stage and writes Variants.csv (+ Evaluation.xlsx later).

QUICK START
  pip install -r requirements.txt
  python pipeline.py eda   dataset.txt        # 1. look at the data (vocab size, hapax, top words)
  python pipeline.py mine  dataset.txt        # 2. discover real alternations (o/u, e/i...) -> edit config.py
  python pipeline.py run   dataset.txt        # 3. full pipeline -> Variants.csv (+ debug_scored.csv for tuning)
  python pipeline.py eval  Variants.csv       # 4. (Dec 1) random 100 pairs -> Evaluation.xlsx with precision formula

PIPELINE   load -> vocab filter -> candidates (edit distance) -> cheap rule filter -> context evidence
           -> score each pair -> drop hubs -> sort -> CSV
FILE MAP   config.py (settings/rules) | data_loading.py | edit_distance.py | alignment_diff.py
           candidates.py | rule_mining.py | scoring.py | grouping.py | parallel_dc.py | pipeline.py
"""
import argparse, random
import pandas as pd
from tqdm import tqdm
from config import CFG
from data_loading import build_vocab, collect_evidence, eda
from candidates import candidate_pairs
from rule_mining import mine_rules, suggest_classes, rule_explains
from scoring import score_pair
from grouping import drop_hubs
from alignment_diff import character_difference

COLUMNS = ["word1", "word2", "word1_count", "word2_count", "character_difference"]

def vocab_for_pairing(cfg=CFG):
    counts = build_vocab(cfg)
    words = [w for w, c in counts.items() if c >= cfg.min_count and len(w) >= cfg.min_len]
    print(f"vocab {len(counts):,} -> {len(words):,} after min_count/min_len filters")
    return counts, words

def run(cfg=CFG):
    counts, words = vocab_for_pairing(cfg)
    pairs = [p for p in tqdm(candidate_pairs(words, cfg), desc="candidates") if rule_explains(*p, cfg.max_edit)]
    print(f"{len(pairs):,} candidate pairs survive the rule filter")
    targets = {w for p in pairs for w in p}
    contexts, sent_ids = collect_evidence(cfg, targets)         # 2nd pass over data, targets only
    scored = [score_pair(a, b, counts, contexts, sent_ids, cfg) for a, b in tqdm(pairs, desc="scoring")]
    dbg = pd.DataFrame(scored)
    dbg.to_csv("debug_scored.csv", index=False)                  # inspect rejected pairs to tune thresholds
    kept = drop_hubs([(r["word1"], r["word2"]) for r in scored if r["accept"]], cfg)
    rows = []
    for a, b in kept:
        w1, w2 = sorted((a, b))
        rows.append((w1, w2, counts[w1], counts[w2], character_difference(w1, w2)))
    df = pd.DataFrame(rows, columns=COLUMNS)
    df = df.assign(_t=df.word1_count + df.word2_count).sort_values("_t", ascending=False).drop(columns="_t")
    if cfg.commas_in_counts:
        df["word1_count"] = df["word1_count"].map("{:,}".format); df["word2_count"] = df["word2_count"].map("{:,}".format)
    df.to_csv(cfg.out_csv, index=False, encoding="utf-8")
    print(f"{len(df):,} variant pairs -> {cfg.out_csv}   (rejected pairs + reasons in debug_scored.csv)")
    return df

def mine(cfg=CFG):
    """Mine edit patterns from ALL close pairs (no rule filter) to discover the real alternations."""
    counts, words = vocab_for_pairing(cfg)
    df = mine_rules(candidate_pairs(words, cfg), counts)
    print(df.head(30).to_string(index=False))
    print("\nSuggested EQUIV_CLASSES additions:", suggest_classes(df))
    df.to_csv("mined_rules.csv", index=False)

def make_eval_sample(csv_path=None, cfg=CFG):
    """Random sample of word pairs -> Evaluation.xlsx with a Yes/No dropdown and a precision formula."""
    from openpyxl import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    df = pd.read_csv(csv_path or cfg.out_csv)
    n = min(cfg.eval_sample_size, len(df))
    sample = df.sample(n=n, random_state=cfg.seed).reset_index(drop=True)
    wb = Workbook(); ws = wb.active; ws.title = "Evaluation"
    ws.append(["#"] + list(df.columns) + ["is_variant (Yes/No)", "notes"])
    for i, r in sample.iterrows(): ws.append([i + 1] + list(r.values))
    last, col = n + 1, len(df.columns) + 2
    L = ws.cell(row=1, column=col).column_letter
    dv = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True); ws.add_data_validation(dv)
    dv.add(f"{L}2:{L}{last}")
    ws["K1"], ws["K2"], ws["K3"], ws["K4"] = "Yes", "No", "Judged", "Precision"
    ws["L1"] = f'=COUNTIF({L}2:{L}{last},"Yes")'; ws["L2"] = f'=COUNTIF({L}2:{L}{last},"No")'
    ws["L3"] = "=L1+L2"; ws["L4"] = '=IF(L3=0,"",L1/L3)'; ws["L4"].number_format = "0.0%"
    for c, wdt in zip("ABCDEFGH", (5, 14, 14, 12, 12, 20, 18, 30)): ws.column_dimensions[c].width = wdt
    wb.save(cfg.eval_xlsx); print(f"{n} random pairs -> {cfg.eval_xlsx} (fill column {L}; precision in L4)")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["eda", "mine", "run", "eval"])
    ap.add_argument("path", help="dataset path (eda/mine/run) or Variants.csv (eval)")
    ap.add_argument("--out", help="output CSV for `run`")
    a = ap.parse_args()
    if a.command == "eval":
        make_eval_sample(a.path)
    else:
        CFG.dataset_path = a.path
        if a.out: CFG.out_csv = a.out
        {"eda": lambda: eda(build_vocab(CFG)), "mine": mine, "run": run}[a.command]()
