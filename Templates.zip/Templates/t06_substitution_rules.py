"""T06 - Linguistically-motivated substitution rules (edit this table to match the dataset!).
A pair is a spelling variant only if ALL differing characters fall in an allowed rule class."""
from t03_alignment_backtrace import align, fast_align

# Symmetric equivalence classes of characters that commonly alternate across orthographies.
EQUIV_CLASSES = [
    {"o", "u"}, {"e", "i"}, {"d", "r"}, {"k", "c"}, {"f", "p"},
    {"s", "z"}, {"w", "u"}, {"y", "i"}, {"j", "h"}, {"b", "v"},
]
ALLOWED = {frozenset(p) for cls in EQUIV_CLASSES for p in [(x, y) for x in cls for y in cls if x != y]}
# Characters that may be inserted/deleted freely (e.g. glottal 'h', doubled letters handled separately).
INDEL_OK = {"h", "'", "-"}

def rule_explains(w1, w2, max_ops=2):
    dist, ops = fast_align(w1, w2)
    if dist == 0 or dist > max_ops:
        return False
    for op, x, y, _ in ops:
        if op == "sub" and frozenset((x, y)) not in ALLOWED:
            return False
        if op in ("ins", "del") and (x or y) not in INDEL_OK:
            return False
    return True

if __name__ == "__main__":
    print(rule_explains("politiko", "pulitiko"))   # True
    print(rule_explains("polittico", "pulitiko"))  # False (doubling + c/k + extra t)
