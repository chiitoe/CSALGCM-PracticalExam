"""T07 - Similarity scores: own LCS DP vs rapidfuzz (LCSseq, Indel, Jaro-Winkler).
Use as extra features/filters (e.g. require JW >= 0.9 AND rule match)."""
from rapidfuzz.distance import LCSseq, Indel, JaroWinkler

def lcs_length(a, b):
    prev = [0] * (len(b) + 1)
    for ca in a:
        cur = [0]
        for j, cb in enumerate(b, 1):
            cur.append(prev[j-1] + 1 if ca == cb else max(prev[j], cur[j-1]))
        prev = cur
    return prev[-1]

def lcs_similarity(a, b):
    return 2 * lcs_length(a, b) / (len(a) + len(b)) if (a or b) else 1.0

def scores(a, b):
    return {"lcs": LCSseq.normalized_similarity(a, b),
            "indel": Indel.normalized_similarity(a, b),
            "jaro_winkler": JaroWinkler.similarity(a, b)}

if __name__ == "__main__":
    assert lcs_length("politiko", "pulitiko") == LCSseq.similarity("politiko", "pulitiko")
    print(lcs_similarity("politiko", "pulitiko"), scores("politiko", "pulitiko"))
