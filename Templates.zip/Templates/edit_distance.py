"""
edit_distance.py  --  Levenshtein in 3 flavours.  (Dynamic Programming: report material!)
  levenshtein / bounded_levenshtein : your own DP (explain these in the report)
  weighted_levenshtein              : DP where o<->u costs 0.3 instead of 1  (linguistically informed)
  fast_distance                     : rapidfuzz (C++), use for the full-scale run
WHEN TO USE : bounded/fast for filtering; weighted for scoring; own DP for the methodology section.
"""
from rapidfuzz.distance import Levenshtein as RF, DamerauLevenshtein as RFD
from config import CFG, INDEL_OK, is_alternation

def levenshtein(a, b):
    """Classic DP, O(n*m) time, O(min(n,m)) memory."""
    if len(a) < len(b): a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]

def bounded_levenshtein(a, b, k):
    """Banded DP with early exit: returns distance if <= k else k+1.  O(k * min(n,m))."""
    if abs(len(a) - len(b)) > k: return k + 1
    if len(a) < len(b): a, b = b, a
    n, m, INF = len(a), len(b), k + 1
    prev = [j if j <= k else INF for j in range(m + 1)]
    for i in range(1, n + 1):
        cur = [INF] * (m + 1)
        if i <= k: cur[0] = i
        row_min = cur[0]
        for j in range(max(1, i - k), min(m, i + k) + 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]), INF)
            row_min = min(row_min, cur[j])
        if row_min > k: return INF
        prev = cur
    return min(prev[m], INF)

def weighted_levenshtein(a, b, cfg=CFG):
    """DP with custom costs: allowed alternation = alt_sub_cost, allowed indel = indel_ok_cost, else 1."""
    def sub(x, y): return 0 if x == y else (cfg.alt_sub_cost if is_alternation(x, y) else 1.0)
    def indel(x): return cfg.indel_ok_cost if x in INDEL_OK else 1.0
    n, m = len(a), len(b)
    prev = [0.0] * (m + 1)
    for j in range(1, m + 1): prev[j] = prev[j - 1] + indel(b[j - 1])
    for i in range(1, n + 1):
        cur = [prev[0] + indel(a[i - 1])]
        for j in range(1, m + 1):
            cur.append(min(prev[j] + indel(a[i - 1]), cur[j - 1] + indel(b[j - 1]),
                           prev[j - 1] + sub(a[i - 1], b[j - 1])))
        prev = cur
    return prev[-1]

def fast_distance(a, b, k=None):
    """rapidfuzz; with k, returns k+1 when the distance exceeds k."""
    return RF.distance(a, b, score_cutoff=k)

def damerau(a, b):
    """Also counts a swapped neighbour pair (e.g. 'ie' vs 'ei') as ONE edit."""
    return RFD.distance(a, b)

if __name__ == "__main__":
    for a, b in [("politiko", "pulitiko"), ("politiko", "polittico"), ("opo", "upo")]:
        assert levenshtein(a, b) == fast_distance(a, b)
        print(f"{a:10} {b:10} lev={levenshtein(a,b)} bounded2={bounded_levenshtein(a,b,2)} "
              f"weighted={weighted_levenshtein(a,b):.2f} damerau={damerau(a,b)}")
