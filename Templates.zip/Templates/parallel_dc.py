"""
parallel_dc.py  --  Divide & Conquer building blocks + multi-core execution.
  merge_sort(items, key)        : classic D&C sort (report material)
  dc_pairs(words, compare)      : recursive halves + boundary window (sorted-neighbourhood method)
  divide_by_key(words, keyfunc) : DIVIDE the vocabulary into independent buckets (e.g. by length or first letter)
  parallel_map(fn, items)       : CONQUER the buckets on all cores with joblib
WHEN TO USE : to speed up scoring on big vocabularies, and to describe D&C in the methodology section.
"""
from collections import defaultdict
from joblib import Parallel, delayed

def merge_sort(items, key=lambda x: x):
    if len(items) <= 1: return list(items)
    mid = len(items) // 2
    L, R = merge_sort(items[:mid], key), merge_sort(items[mid:], key)
    out, i, j = [], 0, 0
    while i < len(L) and j < len(R):
        if key(L[i]) <= key(R[j]): out.append(L[i]); i += 1
        else: out.append(R[j]); j += 1
    return out + L[i:] + R[j:]

def dc_pairs(words, compare, leaf=64, window=20):
    """Divide: halves of a SORTED list. Conquer: recurse. Combine: compare across the split boundary."""
    if len(words) <= leaf:
        return [(a, b) for i, a in enumerate(words) for b in words[i + 1:] if compare(a, b)]
    mid = len(words) // 2
    res = dc_pairs(words[:mid], compare, leaf, window) + dc_pairs(words[mid:], compare, leaf, window)
    res += [(a, b) for a in words[max(0, mid - window):mid] for b in words[mid:mid + window] if compare(a, b)]
    return res

def divide_by_key(items, keyfunc):
    buckets = defaultdict(list)
    for it in items: buckets[keyfunc(it)].append(it)
    return buckets

def chunked(seq, size):
    seq = list(seq)
    return [seq[i:i + size] for i in range(0, len(seq), size)]

def parallel_map(fn, chunks, n_jobs=-1):
    """fn(chunk) -> list; results are concatenated. Use with chunked(pairs, 5000)."""
    return [x for part in Parallel(n_jobs=n_jobs)(delayed(fn)(c) for c in chunks) for x in part]

if __name__ == "__main__":
    ws = merge_sort(["pulitiko", "politiko", "bahay", "baay"])
    print(ws, dc_pairs(ws, lambda a, b: a[0] == b[0]))
    print(parallel_map(lambda c: [x * 2 for x in c], chunked(range(10), 3), n_jobs=2))
