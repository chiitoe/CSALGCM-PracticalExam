"""
parallel_dc.py

Divide and conquer helpers, plus running things on multiple cores.

  merge_sort()      - normal divide and conquer sort
  dc_pairs()        - splits a sorted word list in half, solves each half, then
                      compares words near the split (sorted neighbourhood idea)
  divide_by_key()   - DIVIDE the words into independent buckets (by length, first letter...)
  chunked()         - cut a list into pieces of a given size
  parallel_map()    - CONQUER the pieces on all cores using joblib
"""

from collections import defaultdict

from joblib import Parallel, delayed


def merge_sort(items, key=lambda x: x):
    # base case: 0 or 1 items is already sorted
    if len(items) <= 1:
        return list(items)

    # divide
    middle = len(items) // 2
    left = merge_sort(items[:middle], key)
    right = merge_sort(items[middle:], key)

    # merge the two sorted halves
    merged = []
    i = 0
    j = 0
    while i < len(left) and j < len(right):
        if key(left[i]) <= key(right[j]):
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1

    # one of the halves still has items left
    merged = merged + left[i:] + right[j:]
    return merged


def dc_pairs(words, compare, leaf=64, window=20):
    """
    words must be sorted. compare(a, b) returns True if the pair is a match.
      Divide : split the list in two halves
      Conquer: recurse on each half
      Combine: compare the words close to the split line, since pairs
               across the boundary would be missed otherwise
    """
    # base case: small list, just compare everything
    if len(words) <= leaf:
        found = []
        for i in range(len(words)):
            for j in range(i + 1, len(words)):
                if compare(words[i], words[j]):
                    found.append((words[i], words[j]))
        return found

    middle = len(words) // 2
    left_result = dc_pairs(words[:middle], compare, leaf, window)
    right_result = dc_pairs(words[middle:], compare, leaf, window)
    result = left_result + right_result

    # words just left of the split vs words just right of the split
    left_edge = words[max(0, middle - window):middle]
    right_edge = words[middle:middle + window]
    for a in left_edge:
        for b in right_edge:
            if compare(a, b):
                result.append((a, b))

    return result


def divide_by_key(items, keyfunc):
    # groups the items into a dict: key -> list of items
    buckets = defaultdict(list)
    for item in items:
        buckets[keyfunc(item)].append(item)
    return buckets


def chunked(seq, size):
    seq = list(seq)
    chunks = []
    for i in range(0, len(seq), size):
        chunks.append(seq[i:i + size])
    return chunks


def parallel_map(fn, chunks, n_jobs=-1):
    """
    fn takes one chunk and returns a list. All the lists are joined together.
    Example: parallel_map(fn, chunked(pairs, 5000))
    """
    results_per_chunk = Parallel(n_jobs=n_jobs)(delayed(fn)(chunk) for chunk in chunks)

    all_results = []
    for part in results_per_chunk:
        for item in part:
            all_results.append(item)
    return all_results


if __name__ == "__main__":
    sorted_words = merge_sort(["pulitiko", "politiko", "bahay", "baay"])
    print(sorted_words, dc_pairs(sorted_words, lambda a, b: a[0] == b[0]))
    print(parallel_map(lambda c: [x * 2 for x in c], chunked(range(10), 3), n_jobs=2))
