"""T08 - Group variant pairs into families, pick canonical form (greedy: most frequent).
(a) own Union-Find   (b) networkx connected_components (same result, one line)."""
import networkx as nx

class UnionFind:
    def __init__(self): self.p = {}
    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb: self.p[rb] = ra

def group_variants(pairs):
    uf = UnionFind()
    for a, b in pairs: uf.union(a, b)
    groups = {}
    for w in list(uf.p): groups.setdefault(uf.find(w), []).append(w)
    return list(groups.values())

def group_variants_nx(pairs):
    G = nx.Graph(); G.add_edges_from(pairs)
    return [sorted(c) for c in nx.connected_components(G)]

def canonical(group, counts):
    return max(group, key=lambda w: counts.get(w, 0))

if __name__ == "__main__":
    p = [("politiko", "pulitiko"), ("pulitiko", "pulitikoh")]
    print(group_variants(p), group_variants_nx(p))
