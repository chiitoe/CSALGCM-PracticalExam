"""T10 - End-to-end pipeline + Variants.csv writer (pandas, tqdm, rapidfuzz).
Columns: word1, word2, word1_count, word2_count, character_difference.
Run:  python t10_pipeline_and_csv_writer.py dataset.txt Variants.csv"""
import sys
import pandas as pd
from tqdm import tqdm
from t01_load_and_count import load_counts
from t02_edit_distance import fast_distance
from t03_alignment_backtrace import fast_align
from t05_blocking import candidate_pairs, skeleton, deletion_keys
from t06_substitution_rules import rule_explains

MIN_LEN, MIN_COUNT, MAX_DIST = 5, 2, 2   # opo/upo too short; rare words = typos

def char_diff(a, b):
    return "; ".join(f"{x or '-'} vs. {y or '-'}" for _, x, y, _ in fast_align(a, b)[1])

def is_variant(a, b):
    return (min(len(a), len(b)) >= MIN_LEN
            and fast_distance(a, b, MAX_DIST) <= MAX_DIST
            and rule_explains(a, b, MAX_DIST))

def run(dataset, out_path):
    counts = load_counts(dataset, min_count=MIN_COUNT)
    rows = []
    for a, b in tqdm(candidate_pairs(counts.keys(), key_funcs=(skeleton, deletion_keys)), desc="pairs"):
        if is_variant(a, b):
            w1, w2 = sorted((a, b))
            rows.append((w1, w2, counts[w1], counts[w2], char_diff(w1, w2)))
    df = pd.DataFrame(rows, columns=["word1", "word2", "word1_count", "word2_count", "character_difference"])
    df = df.sort_values(["word1_count", "word2_count"], ascending=False, ignore_index=True)
    df.to_csv(out_path, index=False, encoding="utf-8")
    print(f"{len(df)} pairs written to {out_path}")

if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
