"""
scoring.py  --  decide "same lexical item?" with EVIDENCE, not just spelling similarity.
Signals (all in [0,1] unless noted):
  lexical : 1 - weighted_edit_distance / max_edit        (o<->u is cheap)
  jaro    : Jaro-Winkler similarity
  context : cosine similarity of neighbour-word vectors   <-- the key signal: true variants appear in
            the SAME contexts; opo/upo (different words) do not.
  freq    : min_count / max_count                         (a 1-in-1000 form is probably a typo)
  cooc    : fraction of sentences where both appear together (variants rarely co-occur -> penalty)
Hard filters first (length, edit distance, rule, min_rel_freq), then a weighted score vs score_threshold.
WHEN TO USE : after candidate_pairs(). `score_pair` returns a dict, perfect for a pandas DataFrame.
"""
import math
from rapidfuzz.distance import JaroWinkler
from config import CFG
from edit_distance import fast_distance, weighted_levenshtein
from rule_mining import rule_explains

def cosine(c1, c2):
    if not c1 or not c2: return None
    dot = sum(v * c2.get(k, 0) for k, v in c1.items())
    n1, n2 = math.sqrt(sum(v * v for v in c1.values())), math.sqrt(sum(v * v for v in c2.values()))
    return dot / (n1 * n2) if n1 and n2 else None

def score_pair(a, b, counts, contexts=None, sent_ids=None, cfg=CFG):
    w = cfg.weights
    d = fast_distance(a, b, cfg.max_edit)
    out = dict(word1=a, word2=b, edit=d, reason="")
    if min(len(a), len(b)) < cfg.min_len:   out.update(score=0, accept=False, reason="too short"); return out
    if d > cfg.max_edit:                    out.update(score=0, accept=False, reason="edit too large"); return out
    if not rule_explains(a, b, cfg.max_edit): out.update(score=0, accept=False, reason="no rule"); return out
    ca, cb = counts[a], counts[b]
    freq = min(ca, cb) / max(ca, cb)
    if freq < cfg.min_rel_freq:             out.update(score=0, accept=False, reason="rare form (typo?)"); return out
    lex = max(0.0, 1 - weighted_levenshtein(a, b, cfg) / cfg.max_edit)
    jw = JaroWinkler.similarity(a, b)
    ctx = cosine(contexts.get(a), contexts.get(b)) if contexts else None
    cooc = 0.0
    if sent_ids and sent_ids.get(a) and sent_ids.get(b):
        cooc = len(sent_ids[a] & sent_ids[b]) / min(len(sent_ids[a]), len(sent_ids[b]))
    if ctx is not None and ctx < cfg.min_context_sim:
        out.update(score=0, accept=False, reason=f"contexts differ ({ctx:.2f})"); return out
    ctx_used = ctx if ctx is not None else 0.5               # neutral when no evidence
    score = w["context"] * ctx_used + w["lexical"] * lex + w["jaro"] * jw + w["freq"] * min(1, freq * 2)
    score -= 0.2 * cooc
    out.update(word1_count=ca, word2_count=cb, lexical=round(lex, 3), jaro=round(jw, 3),
               context=None if ctx is None else round(ctx, 3), freq=round(freq, 3), cooc=round(cooc, 3),
               score=round(score, 3), accept=score >= cfg.score_threshold,
               reason="ok" if score >= cfg.score_threshold else "score below threshold")
    return out

if __name__ == "__main__":
    from collections import Counter
    cnt = Counter({"politiko": 435, "pulitiko": 1093, "polittico": 3})
    ctx = {"politiko": Counter(mga=5, ang=4, bayan=3), "pulitiko": Counter(mga=6, ang=5, bayan=2),
           "polittico": Counter(xx=3)}
    for p in [("politiko", "pulitiko"), ("politiko", "polittico")]:
        print(score_pair(*p, cnt, ctx))
