"""
scoring.py

Decides if two words are the same lexical item using evidence, not only how
similar they look. Signals (all between 0 and 1 unless noted):

  lexical : 1 - weighted_edit_distance / max_edit   (o <-> u is cheap)
  jaro    : Jaro-Winkler similarity
  context : cosine similarity of the neighbour-word counts. This is the main
            signal: real variants show up in the same contexts, while
            different words (opo / upo) do not.
  freq    : min_count / max_count  (a form that is 1 in 1000 is probably a typo)
  cooc    : fraction of sentences where both words appear together
            (variants rarely appear together, so this is a penalty)

First some hard filters (length, edit distance, rule, relative frequency),
then a weighted score is compared to score_threshold.
score_pair() returns a dict so a list of results can go straight into a DataFrame.
"""

import math

from rapidfuzz.distance import JaroWinkler

from config import CFG
from edit_distance import fast_distance, weighted_levenshtein
from rule_mining import rule_explains


def cosine(c1, c2):
    # c1 and c2 are dicts / Counters of context word -> count
    if not c1 or not c2:
        return None

    dot = 0
    for word, value in c1.items():
        dot += value * c2.get(word, 0)

    length1 = math.sqrt(sum(v * v for v in c1.values()))
    length2 = math.sqrt(sum(v * v for v in c2.values()))

    if length1 == 0 or length2 == 0:
        return None
    return dot / (length1 * length2)


def score_pair(a, b, counts, contexts=None, sent_ids=None, cfg=CFG):
    weights = cfg.weights
    dist = fast_distance(a, b, cfg.max_edit)
    out = dict(word1=a, word2=b, edit=dist, reason="")

    # ---- hard filters: reject right away ----
    if min(len(a), len(b)) < cfg.min_len:
        out.update(score=0, accept=False, reason="too short")
        return out

    if dist > cfg.max_edit:
        out.update(score=0, accept=False, reason="edit too large")
        return out

    if not rule_explains(a, b, cfg.max_edit):
        out.update(score=0, accept=False, reason="no rule")
        return out

    count_a = counts[a]
    count_b = counts[b]
    freq = min(count_a, count_b) / max(count_a, count_b)
    if freq < cfg.min_rel_freq:
        out.update(score=0, accept=False, reason="rare form (typo?)")
        return out

    # ---- the signals ----
    lex = max(0.0, 1 - weighted_levenshtein(a, b, cfg) / cfg.max_edit)
    jw = JaroWinkler.similarity(a, b)

    ctx = None
    if contexts:
        ctx = cosine(contexts.get(a), contexts.get(b))

    cooc = 0.0
    if sent_ids and sent_ids.get(a) and sent_ids.get(b):
        both = len(sent_ids[a] & sent_ids[b])
        cooc = both / min(len(sent_ids[a]), len(sent_ids[b]))

    # if the contexts are clearly different they are probably different words
    if ctx is not None and ctx < cfg.min_context_sim:
        out.update(score=0, accept=False, reason=f"contexts differ ({ctx:.2f})")
        return out

    # when there is no context info, use 0.5 so it doesn't help or hurt
    if ctx is None:
        ctx_used = 0.5
    else:
        ctx_used = ctx

    # ---- final weighted score ----
    score = (weights["context"] * ctx_used
             + weights["lexical"] * lex
             + weights["jaro"] * jw
             + weights["freq"] * min(1, freq * 2))
    score = score - 0.2 * cooc

    accepted = score >= cfg.score_threshold
    if accepted:
        reason = "ok"
    else:
        reason = "score below threshold"

    if ctx is None:
        ctx_rounded = None
    else:
        ctx_rounded = round(ctx, 3)

    out.update(word1_count=count_a, word2_count=count_b,
               lexical=round(lex, 3), jaro=round(jw, 3),
               context=ctx_rounded, freq=round(freq, 3), cooc=round(cooc, 3),
               score=round(score, 3), accept=accepted, reason=reason)
    return out


if __name__ == "__main__":
    from collections import Counter

    cnt = Counter({"politiko": 435, "pulitiko": 1093, "polittico": 3})
    ctx = {"politiko": Counter(mga=5, ang=4, bayan=3),
           "pulitiko": Counter(mga=6, ang=5, bayan=2),
           "polittico": Counter(xx=3)}

    for pair in [("politiko", "pulitiko"), ("politiko", "polittico")]:
        print(score_pair(*pair, cnt, ctx))
