"""
candidates.py  --  find word pairs worth comparing WITHOUT checking all V^2 pairs.
  cdist_pairs()    : rapidfuzz.process.cdist in row-chunks, multi-core. Simple + exact. Fine up to ~50k words.
  blocking_pairs() : bucket words by cheap keys (consonant skeleton, delete-one-char) and compare inside buckets.
                     Scales to huge vocabularies.
  candidate_pairs(words, cfg) picks one for you (method="auto").
WHEN TO USE : right after building the vocabulary.
"""
from collections import defaultdict
from itertools import combinations
import numpy as np
from rapidfuzz import process
from rapidfuzz.distance import Levenshtein
from config import CFG

VOWELS = set("aeiou")

def skeleton(w):            # politiko / pulitiko -> pltk   (catches vowel alternations)
    return "".join(c for c in w if c not in VOWELS)

def deletion_keys(w):       # SymSpell idea: words within 1 edit share a delete-neighbour
    return {w[:i] + w[i + 1:] for i in range(len(w))}

def cdist_pairs(words, max_edit=2, chunk=1000, n_jobs=-1):
    """Exact: every pair with Levenshtein <= max_edit. Yields (a, b) with a < b."""
    words = sorted(words)
    for start in range(0, len(words), chunk):
        part = words[start:start + chunk]
        M = process.cdist(part, words, scorer=Levenshtein.distance, score_cutoff=max_edit,
                          dtype=np.uint8, workers=n_jobs)
        for r, c in zip(*np.nonzero(M <= max_edit)):
            i = start + r
            if c > i: yield words[i], words[c]

def blocking_pairs(words, key_funcs=(skeleton, deletion_keys), max_block=300):
    blocks = defaultdict(set)
    for w in words:
        for kf in key_funcs:
            for key in (kf(w) if kf is deletion_keys else [kf(w)]):
                blocks[(kf.__name__, key)].add(w)
    seen = set()
    for block in blocks.values():
        if 2 <= len(block) <= max_block:
            for a, b in combinations(sorted(block), 2):
                if (a, b) not in seen:
                    seen.add((a, b)); yield a, b

def candidate_pairs(words, cfg=CFG):
    words = list(words)
    method = cfg.method if cfg.method != "auto" else ("cdist" if len(words) <= 50_000 else "blocking")
    if method == "cdist":
        return cdist_pairs(words, cfg.max_edit, n_jobs=cfg.n_jobs)
    return blocking_pairs(words, max_block=cfg.block_max_size)

if __name__ == "__main__":
    ws = ["politiko", "pulitiko", "opo", "upo", "bahay", "polittico"]
    print("cdist   :", sorted(cdist_pairs(ws)))
    print("blocking:", sorted(blocking_pairs(ws)))
