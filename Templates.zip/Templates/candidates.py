"""
candidates.py

Goal: get pairs of words that are worth comparing, without having to
compare every word with every other word (that would be V^2 comparisons).

Two ways to do it:
  1. cdist_pairs()    - compares everything using rapidfuzz in chunks. Exact,
                        but only practical for smaller vocabularies (~50k words).
  2. blocking_pairs() - puts words into "buckets" using cheap keys and only
                        compares words that share a bucket. Works for big vocab.

candidate_pairs() chooses one of them depending on the config.
Use this right after the vocabulary is built.
"""

from collections import defaultdict
from itertools import combinations

import numpy as np
from rapidfuzz import process
from rapidfuzz.distance import Levenshtein

from config import CFG

VOWELS = set("aeiou")


def skeleton(word):
    # removes the vowels, so politiko and pulitiko both become pltk
    result = ""
    for ch in word:
        if ch not in VOWELS:
            result += ch
    return result


def deletion_keys(word):
    # delete one letter at every position. Two words that are 1 edit apart
    # will share at least one of these (idea taken from SymSpell)
    keys = set()
    for i in range(len(word)):
        keys.add(word[:i] + word[i + 1:])
    return keys


def cdist_pairs(words, max_edit=2, chunk=1000, n_jobs=-1):
    """Yields every pair (a, b) with a < b whose Levenshtein distance is <= max_edit."""
    words = sorted(words)

    # go through the words in chunks so the distance matrix doesn't get too big
    for start in range(0, len(words), chunk):
        part = words[start:start + chunk]
        matrix = process.cdist(part, words, scorer=Levenshtein.distance,
                               score_cutoff=max_edit, dtype=np.uint8, workers=n_jobs)

        rows, cols = np.nonzero(matrix <= max_edit)
        for r, c in zip(rows, cols):
            i = start + r
            # only keep the pair when c > i, otherwise we get duplicates
            if c > i:
                yield words[i], words[c]


def blocking_pairs(words, key_funcs=(skeleton, deletion_keys), max_block=300):
    # step 1: put every word into buckets
    blocks = defaultdict(set)
    for word in words:
        for key_func in key_funcs:
            if key_func is deletion_keys:
                keys = key_func(word)       # this one gives many keys
            else:
                keys = [key_func(word)]     # this one gives just one key
            for key in keys:
                blocks[(key_func.__name__, key)].add(word)

    # step 2: compare the words inside each bucket
    seen = set()
    for block in blocks.values():
        # skip buckets that are too small or too big (huge ones are mostly noise)
        if len(block) < 2 or len(block) > max_block:
            continue
        for a, b in combinations(sorted(block), 2):
            if (a, b) not in seen:
                seen.add((a, b))
                yield a, b


def candidate_pairs(words, cfg=CFG):
    words = list(words)

    if cfg.method == "auto":
        if len(words) <= 50_000:
            method = "cdist"
        else:
            method = "blocking"
    else:
        method = cfg.method

    if method == "cdist":
        return cdist_pairs(words, cfg.max_edit, n_jobs=cfg.n_jobs)
    return blocking_pairs(words, max_block=cfg.block_max_size)


if __name__ == "__main__":
    test_words = ["politiko", "pulitiko", "opo", "upo", "bahay", "polittico"]
    print("cdist   :", sorted(cdist_pairs(test_words)))
    print("blocking:", sorted(blocking_pairs(test_words)))
