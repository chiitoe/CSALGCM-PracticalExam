"""T09 - Divide and Conquer: merge sort + recursive pair search, then multiprocessing
to run the 'conquer' step on chunks in parallel (divide = split blocks across CPU cores)."""
from multiprocessing import Pool, cpu_count

def merge_sort(items, key=lambda x: x):
    if len(items) <= 1: return items
    mid = len(items) // 2
    left, right = merge_sort(items[:mid], key), merge_sort(items[mid:], key)
    out, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if key(left[i]) <= key(right[j]): out.append(left[i]); i += 1
        else: out.append(right[j]); j += 1
    return out + left[i:] + right[j:]

def dc_pairs(words, compare, leaf=64, window=20):
    if len(words) <= leaf:
        return [(a, b) for i, a in enumerate(words) for b in words[i+1:] if compare(a, b)]
    mid = len(words) // 2
    res = dc_pairs(words[:mid], compare, leaf, window) + dc_pairs(words[mid:], compare, leaf, window)
    for a in words[max(0, mid - window):mid]:
        for b in words[mid:mid + window]:
            if compare(a, b): res.append((a, b))
    return res

def _check(pair_chunk_and_fn):
    pairs, fn = pair_chunk_and_fn
    return [p for p in pairs if fn(*p)]

def parallel_filter(pairs, fn, workers=None, chunk=5000):
    """`fn` must be a top-level (picklable) function. Run under `if __name__ == '__main__':`."""
    pairs = list(pairs)
    chunks = [(pairs[i:i+chunk], fn) for i in range(0, len(pairs), chunk)]
    with Pool(workers or cpu_count()) as pool:
        return [p for part in pool.map(_check, chunks) for p in part]

def _demo(a, b): return a[0] == b[0]

if __name__ == "__main__":
    ws = merge_sort(["pulitiko", "politiko", "bahay", "baay"])
    print(ws, dc_pairs(ws, _demo), parallel_filter([("a1", "a2"), ("a1", "b1")], _demo, workers=2))
