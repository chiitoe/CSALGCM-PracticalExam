"""T02 - Levenshtein distance.
(a) own DP + banded DP  -> for the methodology/report (shows you understand the algorithm)
(b) rapidfuzz           -> C++ speed for the real run. Both must agree; test them against each other."""
from rapidfuzz.distance import Levenshtein as RFLev

def levenshtein(a, b):
    if len(a) < len(b): a, b = b, a
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j-1] + 1, prev[j-1] + (ca != cb)))
        prev = cur
    return prev[-1]

def bounded_levenshtein(a, b, k):
    """Own banded DP: distance if <= k else k+1. O(k * min(n,m))."""
    if abs(len(a) - len(b)) > k: return k + 1
    if len(a) < len(b): a, b = b, a
    n, m, INF = len(a), len(b), k + 1
    prev = [j if j <= k else INF for j in range(m + 1)]
    for i in range(1, n + 1):
        cur = [INF] * (m + 1)
        if i <= k: cur[0] = i
        row_min = cur[0]
        for j in range(max(1, i - k), min(m, i + k) + 1):
            cur[j] = min(prev[j] + 1, cur[j-1] + 1, prev[j-1] + (a[i-1] != b[j-1]), INF)
            row_min = min(row_min, cur[j])
        if row_min > k: return INF
        prev = cur
    return min(prev[m], INF)

def fast_distance(a, b, k=None):
    """rapidfuzz; score_cutoff=k makes it return k+1 when distance exceeds k."""
    return RFLev.distance(a, b, score_cutoff=k)

if __name__ == "__main__":
    for a, b in [("politiko", "pulitiko"), ("politiko", "polittico"), ("opo", "upo")]:
        assert levenshtein(a, b) == fast_distance(a, b) == RFLev.distance(a, b)
        print(a, b, levenshtein(a, b), bounded_levenshtein(a, b, 2), fast_distance(a, b, 2))
