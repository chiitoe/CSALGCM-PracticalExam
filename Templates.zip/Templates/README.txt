Templates (Python 3.9+).  Install: pip install -r requirements.txt   (keep all files in one folder)
t01 load/tokenize/count (regex, pandas)     t06 substitution-rule filter
t02 Levenshtein: own DP + banded + rapidfuzz t07 similarity: own LCS + rapidfuzz LCS/Indel/Jaro-Winkler
t03 alignment: own backtrace + rapidfuzz     t08 grouping: own Union-Find + networkx
t04 character_difference column              t09 divide & conquer + multiprocessing
t05 blocking / candidate generation          t10 pipeline + Variants.csv writer (pandas, tqdm)
