"""
grouping.py  --  turn pairs into variant FAMILIES and clean them (Greedy choices).
  group_variants()  : Union-Find (own) -- merges transitive variants  a~b, b~c  =>  {a,b,c}
  group_variants_nx : same with networkx
  canonical()       : greedy pick of the most frequent spelling
  drop_hubs()       : remove words linked to too many partners (usually false positives)
WHEN TO USE : after scoring, before writing Variants.csv.
"""
from collections import Counter
import networkx as nx
from config import CFG

class UnionFind:
    def __init__(self): self.p = {}
    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]; x = self.p[x]     # path compression
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb: self.p[rb] = ra

def group_variants(pairs):
    uf = UnionFind()
    for a, b in pairs: uf.union(a, b)
    groups = {}
    for w in list(uf.p): groups.setdefault(uf.find(w), []).append(w)
    return [sorted(g) for g in groups.values()]

def group_variants_nx(pairs):
    G = nx.Graph(); G.add_edges_from(pairs)
    return [sorted(c) for c in nx.connected_components(G)]

def canonical(group, counts):
    return max(group, key=lambda w: counts.get(w, 0))

def drop_hubs(pairs, cfg=CFG):
    """Keep only pairs whose both words have <= max_partners partners."""
    pairs = list(pairs)
    deg = Counter(w for p in pairs for w in p)
    return [p for p in pairs if deg[p[0]] <= cfg.max_partners and deg[p[1]] <= cfg.max_partners]

if __name__ == "__main__":
    ps = [("politiko", "pulitiko"), ("pulitiko", "pulitikoh")]
    print(group_variants(ps), group_variants_nx(ps), drop_hubs(ps))
