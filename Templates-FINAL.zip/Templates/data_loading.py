"""
data_loading.py  --  read ANY dataset, normalize, tokenize, count, and gather context evidence.
WHEN TO USE : first step of the pipeline. Also run `python data_loading.py <file>` for a quick EDA.
KEY FUNCTIONS: build_vocab(cfg) -> Counter | collect_evidence(cfg, targets) -> (contexts, sent_ids) | eda(counts)
"""
import json, os, unicodedata
from collections import Counter, defaultdict
import regex
from config import CFG

TOKEN_RE = regex.compile(r"\p{L}+(?:'\p{L}+)?")          # letters of any script (+ inner apostrophe)
SENT_SPLIT = regex.compile(r"(?<=[.!?])\s+|\n+")

def normalize(text, cfg=CFG):
    text = unicodedata.normalize("NFKC", text).replace("’", "'").replace("`", "'")
    return text.lower() if cfg.lowercase else text

def tokenize(text, cfg=CFG):
    return TOKEN_RE.findall(normalize(text, cfg))

def iter_texts(path=None, cfg=CFG):
    """Yield raw text chunks from a .txt/.csv/.json/.jsonl file or a folder of them."""
    path = path or cfg.dataset_path
    if os.path.isdir(path):
        for name in sorted(os.listdir(path)):
            yield from iter_texts(os.path.join(path, name), cfg)
        return
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        import pandas as pd
        for chunk in pd.read_csv(path, usecols=[cfg.text_column], chunksize=50_000,
                                 encoding=cfg.encoding, on_bad_lines="skip"):
            yield from chunk[cfg.text_column].dropna().astype(str)
    elif ext in (".json", ".jsonl"):
        with open(path, encoding=cfg.encoding, errors="ignore") as f:
            if ext == ".jsonl":
                for line in f:
                    try: yield str(json.loads(line).get(cfg.text_column, ""))
                    except Exception: continue
            else:
                data = json.load(f)
                for row in (data if isinstance(data, list) else [data]):
                    yield str(row.get(cfg.text_column, "")) if isinstance(row, dict) else str(row)
    else:                                                     # plain text: stream line by line
        with open(path, encoding=cfg.encoding, errors="ignore") as f:
            yield from f

def iter_sentences(path=None, cfg=CFG):
    """Yield token lists, one per sentence."""
    for chunk in iter_texts(path, cfg):
        for sent in SENT_SPLIT.split(chunk):
            toks = tokenize(sent, cfg)
            if toks: yield toks

def build_vocab(cfg=CFG, path=None):
    """Counter of word frequencies (all words; min_count is applied later so EDA stays honest)."""
    counts = Counter()
    for toks in iter_sentences(path, cfg): counts.update(toks)
    return counts

def collect_evidence(cfg, targets, path=None):
    """
    One extra pass that gathers, ONLY for `targets` (memory-friendly):
      contexts[w] = Counter of neighbouring words within +/- context_window
      sent_ids[w] = set of sentence ids where w occurs (to test co-occurrence)
    """
    targets = set(targets)
    contexts, sent_ids = defaultdict(Counter), defaultdict(set)
    w = cfg.context_window
    for sid, toks in enumerate(iter_sentences(path, cfg)):
        for i, tok in enumerate(toks):
            if tok in targets:
                contexts[tok].update(toks[max(0, i - w):i] + toks[i + 1:i + 1 + w])
                sent_ids[tok].add(sid)
    return contexts, sent_ids

def eda(counts, cfg=CFG):
    import pandas as pd
    s = pd.Series(counts)
    print(f"tokens: {s.sum():,} | vocab: {len(s):,} | hapax: {(s == 1).sum():,} "
          f"| vocab with count >= {cfg.min_count}: {(s >= cfg.min_count).sum():,}")
    print("word-length distribution:\n", pd.Series([len(w) for w in s.index]).describe().round(2).to_string())
    print("top 15:", s.sort_values(ascending=False).head(15).to_dict())

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1: CFG.dataset_path = sys.argv[1]
    eda(build_vocab(CFG))
