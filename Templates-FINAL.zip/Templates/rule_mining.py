"""
rule_mining.py  --  LEARN which character alternations occur in YOUR dataset (data-driven rules).
WORKFLOW (very useful, do this first!):
  1. python pipeline.py mine <dataset>      -> prints a ranked table of edits (o->u, e->i, ...)
  2. Look at the top rows; the genuine alternations are frequent and shared by many word pairs.
  3. Copy them into EQUIV_CLASSES in config.py.
Also provides rule_explains(a, b): do ALL differences between a and b fall in allowed alternations?
"""
import pandas as pd
from config import CFG, INDEL_OK, is_alternation
from alignment_diff import diff_chunks

def mine_rules(pairs, counts):
    """pairs: iterable of (a, b) near-neighbours. Returns a DataFrame ranked by #distinct pairs."""
    rows = {}
    for a, b in pairs:
        chunks = diff_chunks(a, b)
        if len(chunks) != 1: continue                       # only single-site edits: clean evidence
        x, y = sorted(chunks[0])
        r = rows.setdefault((x, y), [0, 0, []])
        r[0] += 1; r[1] += min(counts[a], counts[b]); r[2].append(f"{a}/{b}")
    df = pd.DataFrame([(x or "-", y or "-", n, tot, ", ".join(ex[:3]))
                       for (x, y), (n, tot, ex) in rows.items()],
                      columns=["char_1", "char_2", "n_pairs", "support_count", "examples"])
    return df.sort_values(["n_pairs", "support_count"], ascending=False, ignore_index=True)

def suggest_classes(df, min_pairs=5):
    """Quick suggestion of EQUIV_CLASSES lines (single-char pairs only)."""
    top = df[(df.n_pairs >= min_pairs) & (df.char_1.str.len() == 1) & (df.char_2.str.len() == 1)
             & (df.char_1 != "-") & (df.char_2 != "-")]
    return [{r.char_1, r.char_2} for r in top.itertuples()]

def rule_explains(a, b, max_ops=2):
    """True if every differing block is an allowed substitution (or allowed indel)."""
    chunks = diff_chunks(a, b)
    if not chunks or len(chunks) > max_ops: return False
    for x, y in chunks:
        if x and y:                                         # substitution block
            if len(x) != len(y) or not all(is_alternation(p, q) for p, q in zip(x, y)): return False
        elif not set(x + y) <= INDEL_OK:                    # pure insertion/deletion
            return False
    return True

if __name__ == "__main__":
    print(rule_explains("politiko", "pulitiko"), rule_explains("polittico", "pulitiko"))
