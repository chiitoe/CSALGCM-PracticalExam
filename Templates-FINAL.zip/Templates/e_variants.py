"""
Template 5: english_variants_optimized.py
Role: Standalone, single-file optimized English (US/UK) Spelling Variant Extractor.
Run:  python english_variants_optimized.py dataset.txt Variants.csv
"""
import csv
import re
import sys
from collections import Counter
from typing import List, Tuple

try:
    from rapidfuzz.distance import Levenshtein as RFLev
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False


def merge_sort_vocab(words: List[str]) -> List[str]:
    """Divide and Conquer Merge Sort: O(N log N) sorting by (length, alphabetical)."""
    if len(words) <= 1:
        return words
    mid = len(words) // 2
    left, right = merge_sort_vocab(words[:mid]), merge_sort_vocab(words[mid:])
    merged, i, j = [], 0, 0
    while i < len(left) and j < len(right):
        if (len(left[i]), left[i]) <= (len(right[j]), right[j]):
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def dp_edit_distance(s1: str, s2: str, max_allowed: int = 2) -> int:
    """Dynamic Programming Levenshtein Distance (supports up to 2 for -re/-er & -ogue/-og)."""
    if abs(len(s1) - len(s2)) > max_allowed:
        return -1
    if HAS_RAPIDFUZZ:
        d = RFLev.distance(s1, s2, score_cutoff=max_allowed)
        return d if d <= max_allowed else -1

    m, n = len(s1), len(s2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    for i in range(1, m + 1):
        row_min = 999
        for j in range(1, n + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else 1
            dp[i][j] = min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            if dp[i][j] < row_min:
                row_min = dp[i][j]
        if row_min > max_allowed:
            return -1
    return dp[m][n] if dp[m][n] <= max_allowed else -1


def generate_english_candidates(word: str) -> List[Tuple[str, str]]:
    """
    Greedy deterministic US/UK rule generator.
    Outputs (candidate_variant, character_difference) tuples.
    """
    candidates = []

    # Rule 1: -our vs -or (e.g., colour/color, behaviour/behavior, colourful/colorful)
    for match in re.finditer(r"our", word):
        idx = match.start()
        if idx >= 2:
            candidates.append((word[:idx] + "or" + word[idx + 3:], "our vs. or"))

    # Rule 2: -ise/-isation/-yse vs -ize/-ization/-yze (realise/realize, analyse/analyze)
    for s_uk, s_us in [
        ("isation", "ization"), ("isations", "izations"),
        ("ising", "izing"), ("ised", "ized"),
        ("ise", "ize"), ("ises", "izes"),
        ("yse", "yze"), ("ysing", "yzing"), ("ysed", "yzed"),
    ]:
        if word.endswith(s_uk) and len(word) >= len(s_uk) + 2:
            candidates.append((word[:-len(s_uk)] + s_us, "s vs. z"))

    # Rule 3: -ence vs -ense (defence/defense, offence/offense, licence/license)
    if word.endswith("ence") and len(word) >= 6:
        candidates.append((word[:-4] + "ense", "c vs. s"))

    # Rule 4: -re vs -er (centre/center, theatre/theater, fibre/fiber, calibre/caliber)
    if word.endswith("re") and len(word) >= 6 and word[-3] in "tmbgl":
        candidates.append((word[:-2] + "er", "re vs. er"))

    # Rule 5: Double -ll- vs Single -l- before vowel suffix (travelling/traveling, cancelled/canceled)
    for match in re.finditer(r"ll(ing|ed|er|ers|or|ors|y|ous)", word):
        idx = match.start()
        if idx >= 3:
            candidates.append((word[:idx] + "l" + word[idx + 2:], "ll vs. l"))

    # Rule 6: Classical digraphs ae/oe -> e (anaemia/anemia, paediatric/pediatric, oestrogen/estrogen)
    for digraph in ("ae", "oe"):
        if digraph in word and len(word) >= 6:
            candidates.append((word.replace(digraph, "e", 1), f"{digraph} vs. e"))

    # Rule 7: -ogue vs -og (catalogue/catalog, dialogue/dialog) & -mme vs -m (programme/program)
    if word.endswith("ogue") and len(word) >= 7:
        candidates.append((word[:-2], "ogue vs. og"))
    if word.endswith("mme") and len(word) >= 7:
        candidates.append((word[:-2], "mme vs. m"))

    return candidates


def extract_english_variants(counts: Counter) -> List[Tuple[str, str, int, int, str]]:
    vocab = merge_sort_vocab([w for w in counts if len(w) >= 5])
    vocab_set = set(vocab)
    results, seen = [], set()

    for w1 in vocab:
        for w2, cdiff in generate_english_candidates(w1):
            if w2 in vocab_set and w1 != w2:
                dist = dp_edit_distance(w1, w2, max_allowed=2)
                if dist in (1, 2):
                    pair_key = tuple(sorted((w1, w2)))
                    if pair_key not in seen:
                        seen.add(pair_key)
                        results.append((w1, w2, counts[w1], counts[w2], cdiff))

    results.sort(key=lambda r: (r[2], r[3]), reverse=True)
    return results


if __name__ == "__main__":
    in_file = sys.argv[1] if len(sys.argv) > 1 else "dataset.txt"
    out_file = sys.argv[2] if len(sys.argv) > 2 else "Variants.csv"
    counts = Counter()
    pattern = re.compile(r"[a-zA-Z]+")
    with open(in_file, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            counts.update(pattern.findall(line.lower()))

    variants = extract_english_variants(counts)
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["word1", "word2", "word1_count", "word2_count", "character_difference"])
        writer.writerows(variants)
    print(f"English Pipeline: Extracted {len(variants)} pairs to {out_file}.")