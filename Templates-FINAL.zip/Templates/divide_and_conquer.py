"""
Template 3: divide_and_conquer_pipeline.py
Role: Modular Divide & Conquer Pipeline connecting dp_edit_distance and greedy_rule_matcher.
"""
import csv
import re
import sys
from collections import Counter, defaultdict
from typing import List, Tuple
from dp_edit_distance import analyze_edit_distance_one
from greedy_rule_matcher import is_valid_spelling_variant


def merge_sort_words(words: List[str]) -> List[str]:
    """Divide and Conquer Merge Sort: sorts vocabulary by (length, alphabetical order) in O(N log N)."""
    if len(words) <= 1:
        return words
    mid = len(words) // 2
    left = merge_sort_words(words[:mid])
    right = merge_sort_words(words[mid:])

    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        if (len(left[i]), left[i]) <= (len(right[j]), right[j]):
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def load_and_count_corpus(filepath: str) -> Counter:
    counts = Counter()
    word_pattern = re.compile(r"[a-zA-ZñÑ]+")
    with open(filepath, mode="r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            counts.update(word_pattern.findall(line.lower()))
    return counts


def extract_variants_divide_and_conquer(word_counts: Counter) -> List[Tuple[str, str, int, int, str]]:
    """
    Divide & Conquer Partitioning:
    1. Sorts vocabulary via Merge Sort.
    2. Divides words into O(N * L) wildcard micro-buckets for substitutions.
    3. Checks O(1) direct hash lookups for uw/w and iy/y glide reductions.
    """
    vocab = merge_sort_words([w for w in word_counts if len(w) >= 5])
    vocab_set = set(vocab)
    results = []
    seen_pairs = set()

    # Sub-problem 1: Same-length substitutions via wildcard partitioning
    masked_buckets = defaultdict(list)
    for w in vocab:
        for i in range(len(w)):
            masked_buckets[(len(w), i, w[:i] + "*" + w[i + 1:])].append(w)

    for bucket in masked_buckets.values():
        if len(bucket) > 1:
            for i in range(len(bucket)):
                for j in range(i + 1, len(bucket)):
                    w1, w2 = bucket[i], bucket[j]
                    if (w1, w2) not in seen_pairs:
                        alignment = analyze_edit_distance_one(w1, w2)
                        if alignment and is_valid_spelling_variant(w1, w2, alignment):
                            seen_pairs.add((w1, w2))
                            results.append((w1, w2, word_counts[w1], word_counts[w2], alignment.cdiff))

    # Sub-problem 2: Length L vs L-1 glide reductions (CuwV -> CwV, CiyV -> CyV)
    for w_long in vocab:
        if len(w_long) >= 6:
            for i in range(1, len(w_long) - 2):
                if w_long[i:i + 2] in ("uw", "iy"):
                    w_short = w_long[:i] + w_long[i + 1:]
                    if w_short in vocab_set:
                        pair_key = (w_long, w_short)
                        if pair_key not in seen_pairs:
                            alignment = analyze_edit_distance_one(w_long, w_short)
                            if alignment and is_valid_spelling_variant(w_long, w_short, alignment):
                                seen_pairs.add(pair_key)
                                results.append((
                                    w_long, w_short,
                                    word_counts[w_long], word_counts[w_short],
                                    alignment.cdiff
                                ))

    results.sort(key=lambda r: (r[2], r[3]), reverse=True)
    return results


def export_variants_csv(variants: List[Tuple[str, str, int, int, str]], output_csv: str = "Variants.csv"):
    with open(output_csv, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["word1", "word2", "word1_count", "word2_count", "character_difference"])
        writer.writerows(variants)


if __name__ == "__main__":
    in_path = sys.argv[1] if len(sys.argv) > 1 else "dataset.txt"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "Variants.csv"
    counts = load_and_count_corpus(in_path)
    pairs = extract_variants_divide_and_conquer(counts)
    export_variants_csv(pairs, out_path)
    print(f"Extracted {len(pairs)} spelling variant pairs to {out_path}.")