"""
Template 2: greedy_rule_matcher.py
Role: Greedy Generalized N-Gram (C/V) & Linguistic Filter based on Oco et al. (2024).
"""
from dp_edit_distance import AlignmentResult

VOWELS = set("aeiouAEIOU")

# Valid Filipino substitution pairs from Tables 1, 4, and 6 (Abecedario & Modern)
VALID_SUBSTITUTION_PAIRS = {
    frozenset(('o', 'u')),
    frozenset(('e', 'i')),
    frozenset(('d', 'r')),
    frozenset(('c', 'k')),
    frozenset(('v', 'b')),
    frozenset(('i', 'y')),
    frozenset(('o', 'w')),
    frozenset(('f', 'p')),
    frozenset(('s', 'z')),
}

# Explicit non-variants from Oco et al. (2024) Table 2 & Table 3
KNOWN_NON_VARIANTS = {
    frozenset(("opo", "upo")),
    frozenset(("pare", "pari")),
    frozenset(("madikit", "marikit")),
    frozenset(("pauwi", "pawi")),
    frozenset(("paiyak", "payak")),
    frozenset(("aabutan", "aabutin")),
}


def is_vowel(ch: str) -> bool:
    return ch in VOWELS


def is_consonant(ch: str) -> bool:
    return ch.isalpha() and ch not in VOWELS


def to_generalized_cv(text: str) -> str:
    """Converts string into generalized 'C' (consonant) and 'V' (vowel) pattern."""
    return "".join('V' if is_vowel(c) else ('C' if is_consonant(c) else '_') for c in text)


def has_double_consonant(word: str) -> bool:
    """Greedily rejects non-Filipino double consonants (e.g., Italian 'polittico', English 'robber')."""
    for i in range(len(word) - 1):
        if word[i] == word[i + 1] and is_consonant(word[i]):
            return True
    return False


def matches_100_percent_precision_rules(w1: str, w2: str) -> bool:
    """
    Greedily checks the 4 rules with 100% precision from Table 5 of Oco et al. (2024):
    1. ehVC vs. ihVC (doblehin vs. doblihin)
    2. omC vs. umC   (kompanya vs. kumpanya)
    3. CuwV vs. CwV  (lengguwahe vs. lenggwahe)
    4. CiyV vs. CyV  (ahensiya vs. ahensya)
    """
    if len(w1) == len(w2):
        for i in range(len(w1)):
            if w1[i] != w2[i]:
                pair = {w1[i], w2[i]}
                if pair == {'e', 'i'} and i + 3 < len(w1):
                    if w1[i + 1] == 'h' and is_vowel(w1[i + 2]) and is_consonant(w1[i + 3]):
                        return True
                if pair == {'o', 'u'} and i + 2 < len(w1):
                    if w1[i + 1] == 'm' and is_consonant(w1[i + 2]):
                        return True
                break
    elif abs(len(w1) - len(w2)) == 1:
        longer, shorter = (w1, w2) if len(w1) > len(w2) else (w2, w1)
        idx = 0
        while idx < len(shorter) and longer[idx] == shorter[idx]:
            idx += 1
        if 0 < idx and idx + 2 < len(longer):
            if is_consonant(longer[idx - 1]) and is_vowel(longer[idx + 2]):
                if longer[idx:idx + 2] in ("uw", "iy"):
                    return True
    return False


def is_valid_spelling_variant(word1: str, word2: str, alignment: AlignmentResult) -> bool:
    """Greedy validation filter combining Table 5 rules with structural constraints."""
    if alignment is None or alignment.edit_distance != 1:
        return False

    w1, w2 = word1.lower(), word2.lower()
    if frozenset((w1, w2)) in KNOWN_NON_VARIANTS:
        return False
    if has_double_consonant(w1) or has_double_consonant(w2):
        return False

    # Tier 1: Immediate pass for Oco et al. (2024) Table 5 100%-precision rules
    if matches_100_percent_precision_rules(w1, w2):
        return True

    # Reject short words (<= 5 chars) to prevent semantic minimal pairs (opo/upo, pare/pari)
    if min(len(w1), len(w2)) <= 5:
        return False

    # Tier 2: Single-character substitutions in longer words (>= 6 chars)
    if len(w1) == len(w2):
        idx = alignment.cdiff_index - 1
        c1, c2 = w1[idx], w2[idx]
        pair = frozenset((c1, c2))
        if pair not in VALID_SUBSTITUTION_PAIRS:
            return False

        # Reject Filipino verb suffix focus shifts (-an vs -in, e.g., aabutan vs. aabutin)
        if idx == len(w1) - 2 and w1.endswith('n'):
            return False

        # For d vs. r, require intervocalic context (V-d-V vs V-r-V, e.g., madumi/marumi)
        if pair == frozenset(('d', 'r')):
            if not (0 < idx < len(w1) - 1 and is_vowel(w1[idx - 1]) and is_vowel(w1[idx + 1])):
                return False

        return True

    return False