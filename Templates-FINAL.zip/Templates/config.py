"""
config.py  --  ONE place for every setting and linguistic rule.
WHEN TO USE : edit this first; every other module reads CFG from here.
TUNE THESE  : min_count, min_len, max_edit, score_threshold, EQUIV_CLASSES.
"""
from dataclasses import dataclass, field

@dataclass
class Config:
    # ---- input / output ----
    dataset_path: str = "dataset.txt"      # file OR folder of .txt/.csv/.json/.jsonl
    text_column: str = "text"              # used for csv / json inputs
    out_csv: str = "Variants.csv"
    encoding: str = "utf-8"
    commas_in_counts: bool = False         # True -> "1,093" like the spec example
    # ---- vocabulary filters ----
    lowercase: bool = True
    min_count: int = 2                     # drop hapax / typos
    min_len: int = 5                       # short words (opo/upo) are different lexical items
    # ---- candidate generation ----
    max_edit: int = 2                      # max Levenshtein distance for a candidate
    method: str = "auto"                   # "auto" | "cdist" | "blocking"
    block_max_size: int = 300              # skip giant, uninformative blocks
    # ---- scoring ----
    context_window: int = 3                # words on each side for context vectors
    min_rel_freq: float = 0.01             # rarer form must be >= 1% of the commoner form
    min_context_sim: float = 0.15          # below this -> probably different words
    score_threshold: float = 0.55          # final accept threshold (0..1)
    weights: dict = field(default_factory=lambda: dict(
        context=0.40, lexical=0.30, jaro=0.15, freq=0.15))
    alt_sub_cost: float = 0.3              # cost of a "known alternation" substitution (o<->u)
    indel_ok_cost: float = 0.5             # cost of inserting/deleting an allowed char (h, ')
    # ---- grouping ----
    max_partners: int = 6                  # a word with more partners than this is suspicious
    # ---- evaluation (Dec 1) ----
    eval_sample_size: int = 100
    eval_xlsx: str = "Evaluation.xlsx"
    seed: int = 42
    n_jobs: int = -1                       # -1 = all CPU cores

CFG = Config()

# ---------- linguistic rules (EDIT AFTER running `python pipeline.py mine ...`) ----------
# Characters in the same set are allowed to alternate: politiko/pulitiko (o<->u), etc.
EQUIV_CLASSES = [
    {"o", "u"}, {"e", "i"}, {"d", "r"}, {"k", "c"}, {"f", "p"},
    {"s", "z"}, {"w", "u"}, {"y", "i"}, {"j", "h"}, {"b", "v"},
]
INDEL_OK = {"h", "'", "-"}                 # may be inserted/deleted freely

ALLOWED_SUBS = {frozenset((x, y)) for cls in EQUIV_CLASSES for x in cls for y in cls if x != y}

def is_alternation(x: str, y: str) -> bool:
    """True if substituting x<->y is an allowed alternation."""
    return frozenset((x, y)) in ALLOWED_SUBS
