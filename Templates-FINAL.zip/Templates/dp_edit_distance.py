"""
Template 1: dp_edit_distance.py
Role: Dynamic Programming Bounded Edit Distance & Feature Extractor (cdiff, index, position).
"""
from dataclasses import dataclass
from typing import Optional

try:
    from rapidfuzz.distance import Levenshtein as RFLev
    HAS_RAPIDFUZZ = True
except ImportError:
    HAS_RAPIDFUZZ = False


@dataclass
class AlignmentResult:
    edit_distance: int
    cdiff: str          # e.g., "o vs. u" or "uw vs. w"
    wdiff_format: str   # e.g., "[-o-]+u+"
    cdiff_index: int    # 1-based index where the difference occurs
    position: str       # "beginning", "middle", or "ending"


def compute_bounded_edit_distance(s1: str, s2: str, max_allowed: int = 1) -> int:
    """
    Space-optimized O(min(M,N)) Banded Dynamic Programming Levenshtein Distance.
    Only computes cells within diagonal band [-max_allowed, +max_allowed].
    Returns -1 if edit distance > max_allowed.
    """
    if abs(len(s1) - len(s2)) > max_allowed:
        return -1
    if len(s1) < len(s2):
        s1, s2 = s2, s1

    m, n = len(s1), len(s2)
    INF = max_allowed + 1
    prev = [j if j <= max_allowed else INF for j in range(n + 1)]

    for i in range(1, m + 1):
        curr = [INF] * (n + 1)
        if i <= max_allowed:
            curr[0] = i
        row_min = curr[0]

        # Banded window: only check j within [i - max_allowed, i + max_allowed]
        start_j = max(1, i - max_allowed)
        end_j = min(n, i + max_allowed)
        c1 = s1[i - 1]

        for j in range(start_j, end_j + 1):
            cost = 0 if c1 == s2[j - 1] else 1
            curr[j] = min(
                prev[j] + 1,         # Deletion
                curr[j - 1] + 1,     # Insertion
                prev[j - 1] + cost   # Substitution
            )
            if curr[j] < row_min:
                row_min = curr[j]

        if row_min > max_allowed:
            return -1
        prev = curr

    return prev[n] if prev[n] <= max_allowed else -1


def fast_verify_distance_one(s1: str, s2: str) -> bool:
    """Uses C++ RapidFuzz if installed, otherwise falls back to Banded DP."""
    if abs(len(s1) - len(s2)) > 1:
        return False
    if HAS_RAPIDFUZZ:
        return RFLev.distance(s1, s2, score_cutoff=1) == 1
    return compute_bounded_edit_distance(s1, s2, max_allowed=1) == 1


def get_position_label(zero_based_idx: int, length: int) -> str:
    if zero_based_idx == 0:
        return "beginning"
    if zero_based_idx == length - 1:
        return "ending"
    return "middle"


def analyze_edit_distance_one(word1: str, word2: str) -> Optional[AlignmentResult]:
    """
    Extracts exact cdiff, wdiff_format, 1-based cdiff_index, and position label
    for pairs with Edit Distance == 1 (Oco et al., 2024 Table 3).
    """
    if not fast_verify_distance_one(word1, word2):
        return None

    len1, len2 = len(word1), len(word2)

    # Case 1: Same-length Substitution (e.g., politiko vs. pulitiko)
    if len1 == len2:
        for i in range(len1):
            if word1[i] != word2[i]:
                c1, c2 = word1[i], word2[i]
                return AlignmentResult(
                    edit_distance=1,
                    cdiff=f"{c1} vs. {c2}",
                    wdiff_format=f"[-{c1}-]+{c2}+",
                    cdiff_index=i + 1,
                    position=get_position_label(i, len1)
                )

    # Case 2: Length differs by 1 (Insertion/Deletion, e.g., kuwento vs. kwento)
    longer, shorter = (word1, word2) if len1 > len2 else (word2, word1)
    diff_idx = 0
    while diff_idx < len(shorter) and longer[diff_idx] == shorter[diff_idx]:
        diff_idx += 1

    extra_char = longer[diff_idx]

    # Check Filipino glide reductions: uw vs. w, iy vs. y
    if extra_char in ('u', 'i') and diff_idx + 1 < len(longer):
        next_char = longer[diff_idx + 1]
        if (extra_char == 'u' and next_char == 'w') or (extra_char == 'i' and next_char == 'y'):
            glide = extra_char + next_char
            cdiff = f"{glide} vs. {next_char}" if len1 > len2 else f"{next_char} vs. {glide}"
            wdiff = f"[-{extra_char}-]" if len1 > len2 else f"+{extra_char}+"
            return AlignmentResult(1, cdiff, wdiff, diff_idx + 1, get_position_label(diff_idx, len(longer)))

    cdiff = f"{extra_char} vs. -" if len1 > len2 else f"- vs. {extra_char}"
    wdiff = f"[-{extra_char}-]" if len1 > len2 else f"+{extra_char}+"
    return AlignmentResult(1, cdiff, wdiff, diff_idx + 1, get_position_label(diff_idx, len(longer)))