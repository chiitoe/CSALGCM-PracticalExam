"""
alignment_diff.py  --  WHICH characters differ?  Builds the `character_difference` column.
  align()                : own DP + traceback (report material)
  diff_chunks(a, b)      : [(x, y), ...] merged contiguous edits, e.g. [('o','u')] or [('ts','ch')]
  character_difference() : "o vs. u"  (several chunks joined by "; ")
WHEN TO USE : output column + rule mining. A deletion/insertion is shown with '-' (change SYMBOL if your spec differs).
"""
from rapidfuzz.distance import Levenshtein as RF

SYMBOL = "-"

def align(a, b):
    """Own DP + traceback. Returns (distance, [(op, char_a, char_b, pos_in_a)])."""
    n, m = len(a), len(b)
    D = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1): D[i][0] = i
    for j in range(m + 1): D[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            D[i][j] = min(D[i-1][j] + 1, D[i][j-1] + 1, D[i-1][j-1] + (a[i-1] != b[j-1]))
    ops, i, j = [], n, m
    while i > 0 or j > 0:
        if i and j and D[i][j] == D[i-1][j-1] + (a[i-1] != b[j-1]):
            if a[i-1] != b[j-1]: ops.append(("sub", a[i-1], b[j-1], i - 1))
            i, j = i - 1, j - 1
        elif i and D[i][j] == D[i-1][j] + 1:
            ops.append(("del", a[i-1], "", i - 1)); i -= 1
        else:
            ops.append(("ins", "", b[j-1], i)); j -= 1
    return D[n][m], ops[::-1]

def diff_chunks(a, b):
    """Merged edit blocks via rapidfuzz opcodes: [(text_in_a, text_in_b), ...]."""
    return [(a[i1:i2], b[j1:j2]) for tag, i1, i2, j1, j2 in RF.opcodes(a, b) if tag != "equal"]

def character_difference(a, b):
    return "; ".join(f"{x or SYMBOL} vs. {y or SYMBOL}" for x, y in diff_chunks(a, b))

if __name__ == "__main__":
    print(align("politiko", "pulitiko"))
    for a, b in [("politiko", "pulitiko"), ("tsaa", "chaa"), ("bahay", "bay")]:
        print(a, b, "->", character_difference(a, b))
